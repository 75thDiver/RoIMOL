# -*- coding: utf-8 -*-
"""ЗЕЛЁНАЯ ВЕТКА v3: Романовы = выбор из 3 путей (свой/союзнический/прогерманский) с большими подветками,
сходящихся в ЕДИНСТВЕННУЮ войну с СССР; восстания в Приднестровье у Романовых и у земской линии;
у процарского восстания свой косметический тег ПМР."""
import os, shutil, datetime

STAMP = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
BK = os.path.join('_devtools', 'backup_monv3_' + STAMP)
FILES = ['common/national_focus/moldova.txt', 'events/transnistria_events.txt',
         'common/countries/cosmetic.txt',
         'localisation/russian/RoIMOL_focus_l_russian.yml',
         'localisation/russian/RoIMOL_countries_l_russian.yml',
         'localisation/russian/RoIMOL_tooltips_l_russian.yml']
os.makedirs(BK, exist_ok=True)
for p in FILES:
    if os.path.isfile(p):
        shutil.copy2(p, os.path.join(BK, p.replace('/', '__')))
print('бэкап ->', BK)

def read(p): return open(p, encoding='utf-8', newline='').read()
def write(p, s): open(p, 'w', encoding='utf-8', newline='').write(s)

T = '\t'
def F(body):
    out = [T + 'focus = {']
    for line in body.strip('\n').split('\n'):
        out.append((T + T + line) if line else '')
    out.append(T + '}')
    return '\n'.join(out)

UPR_AVAIL = '''available = {
\tis_subject = no
\tany_state = {
\t\tOR = { state = 834 state = 192 state = 196 }
\t\towner = {
\t\t\tOR = { original_tag = UKR original_tag = SOV }
\t\t\tNOT = { is_in_faction_with = ROOT }
\t\t}
\t}
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\towns_state = 834
\t\tcountry_exists = PMR
\t}
}'''

# ================= хвост земской линии (восстание на Днестре) =================
NATIVE_TAIL = [
 T + '\t# --- Земское восстание на Днестре (аналог приднестровской цепочки) ---',
 F('''id = MOL_mon_native_uprising
icon = GFX_goal_generic_demand_territory
prerequisite = { focus = MOL_mon_grand_moldavia }
x = 0
y = 1
relative_position_id = MOL_mon_grand_moldavia
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
''' + UPR_AVAIL + '''
completion_reward = {
\tadd_political_power = 50
\tadd_war_support = 0.05
\tadd_stability = -0.05
\tset_country_flag = transnistria_rising
\tset_country_flag = MOL_mon_native_dniester_rising
\tcustom_effect_tooltip = MOL_dem_dniester_uprising_tt
\tunlock_decision_category_tooltip = MOL_transnistria_category
}'''),
 F('''id = MOL_mon_native_agents
icon = GFX_goal_generic_intelligence_exchange
prerequisite = { focus = MOL_mon_native_uprising }
x = 0
y = 1
relative_position_id = MOL_mon_native_uprising
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
available = { has_country_flag = MOL_mon_native_dniester_rising }
completion_reward = {
\tadd_political_power = 50
\tadd_war_support = 0.05
\tset_country_flag = transnistria_agents_bonus
}'''),
 F('''id = MOL_mon_native_volunteers
icon = GFX_goal_generic_allies_build_infantry
prerequisite = { focus = MOL_mon_native_agents }
x = 0
y = 1
relative_position_id = MOL_mon_native_agents
cost = 10
search_filters = { FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
available = { has_country_flag = MOL_mon_native_dniester_rising }
completion_reward = {
\tadd_manpower = 5000
\tadd_equipment_to_stockpile = { type = infantry_equipment amount = 1500 }
\tadd_war_support = 0.05
\tset_country_flag = transnistria_volunteers_bonus
}'''),
 F('''id = MOL_mon_native_reunion
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_native_volunteers }
x = 0
y = 1
relative_position_id = MOL_mon_native_volunteers
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_ANNEXATION }
available_if_capitulated = yes
available = {
\tcountry_exists = PMR
\tPMR = { is_in_faction = no has_war = no }
}
completion_reward = {
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_transnistria_reunion }
\tMOL = { country_event = { id = transnistria_events.3 days = 1 } }
}'''),
]

# ================= НОВАЯ линия Романовых =================
ROM = [
 T + '\t# ==========================================================',
 T + '\t# ЛИНИЯ РОМАНОВЫХ: двор в изгнании и ТРИ пути (свой / союзнический / прогерманский),',
 T + '\t# сходящиеся в единственную войну с СССР',
 T + '\t# ==========================================================',
 F('''id = MOL_mon_romanov_emigre
icon = GFX_goal_generic_allies_build_infantry
prerequisite = { focus = MOL_mon_coronation }
x = 8
y = 1
relative_position_id = MOL_mon_coronation
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 25000
\tadd_war_support = 0.05
\tarmy_experience = 50
\tadd_dynamic_modifier = { modifier = MOL_romanov_court }
}'''),
 T + '\t# --- Выбор пути двора (взаимоисключающие) ---',
 F('''id = MOL_mon_romanov_third_rome
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_romanov_emigre }
mutually_exclusive = { focus = MOL_mon_romanov_allied_path }
mutually_exclusive = { focus = MOL_mon_romanov_german_path }
x = -3
y = 1
relative_position_id = MOL_mon_romanov_emigre
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_war_support = 0.05
\tadd_dynamic_modifier = { modifier = MOL_third_rome }
}'''),
 F('''id = MOL_mon_romanov_allied_path
icon = GFX_goal_generic_alliance
prerequisite = { focus = MOL_mon_romanov_emigre }
mutually_exclusive = { focus = MOL_mon_romanov_third_rome }
mutually_exclusive = { focus = MOL_mon_romanov_german_path }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_emigre
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tENG = { add_opinion_modifier = { target = ROOT modifier = MOL_democratic_cooperation } }
\tFRA = { add_opinion_modifier = { target = ROOT modifier = MOL_democratic_cooperation } }
}'''),
 F('''id = MOL_mon_romanov_german_path
icon = GFX_focus_generic_conspiracy
prerequisite = { focus = MOL_mon_romanov_emigre }
mutually_exclusive = { focus = MOL_mon_romanov_third_rome }
mutually_exclusive = { focus = MOL_mon_romanov_allied_path }
x = 3
y = 1
relative_position_id = MOL_mon_romanov_emigre
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tGER = { add_opinion_modifier = { target = ROOT modifier = MOL_trade_agreement } }
}'''),
 T + '\t# --- СВОЙ ПУТ: самодержавие, церковь, Белая армия и казачество ---',
 F('''id = MOL_mon_romanov_autocracy
icon = GFX_focus_rom_royal_dictatorship
prerequisite = { focus = MOL_mon_romanov_third_rome }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_third_rome
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_imperial_throne }
}'''),
 F('''id = MOL_mon_romanov_white_army
icon = GFX_focus_generic_limited_social_mobilization
prerequisite = { focus = MOL_mon_romanov_autocracy }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_autocracy
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 20000
\tadd_dynamic_modifier = { modifier = MOL_white_army }
}'''),
 F('''id = MOL_mon_romanov_cossacks
icon = GFX_goal_generic_small_arms
prerequisite = { focus = MOL_mon_romanov_white_army }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_white_army
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 50
\tadd_manpower = 10000
\tadd_dynamic_modifier = { modifier = MOL_cossack_hosts }
}'''),
 F('''id = MOL_mon_romanov_orthodoxy
icon = GFX_goal_generic_propaganda
prerequisite = { focus = MOL_mon_romanov_cossacks }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_cossacks
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
}'''),
 T + '\t# --- СОЮЗНИЧЕСКИЙ ПУТ: Антанта, помощь и корпус ---',
 F('''id = MOL_mon_romanov_entente
icon = GFX_goal_generic_major_alliance
prerequisite = { focus = MOL_mon_romanov_allied_path }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_allied_path
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\tevery_other_country = {
\t\tlimit = {
\t\t\tOR = { original_tag = ENG original_tag = FRA original_tag = TUR original_tag = GRE }
\t\t\thas_government = democratic
\t\t\tis_in_faction = no
\t\t\tNOT = { has_war_with = ROOT }
\t\t}
\t\tROOT = { give_guarantee = PREV }
\t}
}'''),
 F('''id = MOL_mon_romanov_allied_aid
icon = GFX_goal_generic_positive_trade_relations
prerequisite = { focus = MOL_mon_romanov_entente }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_entente
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tadd_equipment_to_stockpile = { type = infantry_equipment amount = 3000 }
\tadd_political_power = 50
}'''),
 F('''id = MOL_mon_romanov_allied_corps
icon = GFX_focus_generic_military_academy
prerequisite = { focus = MOL_mon_romanov_allied_aid }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_allied_aid
cost = 15
search_filters = { FOCUS_FILTER_ARMY_XP FOCUS_FILTER_RESEARCH }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 75
\tadd_doctrine_cost_reduction = {
\t\tname = land_doc_bonus
\t\tcost_reduction = 0.5
\t\tuses = 1
\t\tcategory = land_doctrine
\t}
}'''),
 F('''id = MOL_mon_romanov_black_sea_fleet
icon = GFX_goal_generic_navy_cruiser
prerequisite = { focus = MOL_mon_romanov_allied_corps }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_allied_corps
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tnavy_experience = 50
\t766 = {
\t\tadd_building_construction = { type = dockyard level = 1 instant_build = yes }
\t}
}'''),
 T + '\t# --- ПРОГЕРМАНСКИЙ ПУТ: Берлин, лицензии и офицеры ---',
 F('''id = MOL_mon_romanov_berlin_pact
icon = GFX_goal_generic_military_deal
prerequisite = { focus = MOL_mon_romanov_german_path }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_german_path
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\tGER = { add_opinion_modifier = { target = ROOT modifier = MOL_favouritism_in_trading } }
}'''),
 F('''id = MOL_mon_romanov_german_arms
icon = GFX_goal_generic_small_arms
prerequisite = { focus = MOL_mon_romanov_berlin_pact }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_berlin_pact
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tadd_equipment_to_stockpile = { type = infantry_equipment amount = 4000 }
\tadd_war_support = 0.05
}'''),
 F('''id = MOL_mon_romanov_german_officers
icon = GFX_focus_generic_military_mission
prerequisite = { focus = MOL_mon_romanov_german_arms }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_german_arms
cost = 15
search_filters = { FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 75
\tadd_dynamic_modifier = { modifier = MOL_white_army }
}'''),
 F('''id = MOL_mon_romanov_war_industry
icon = GFX_goal_generic_construct_mil_factory
prerequisite = { focus = MOL_mon_romanov_german_officers }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_german_officers
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tadd_war_support = 0.05
\trandom_owned_controlled_state = {
\t\tadd_building_construction = { type = arms_factory level = 1 instant_build = yes }
\t}
}'''),
 T + '\t# --- Общий хвост: восстание царских лоялистов на Днестре -> ЕДИНСТВЕННАЯ война с СССР ---',
 F('''id = MOL_mon_romanov_uprising
icon = GFX_goal_generic_demand_territory
prerequisite = { focus = MOL_mon_romanov_orthodoxy focus = MOL_mon_romanov_black_sea_fleet focus = MOL_mon_romanov_war_industry }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_black_sea_fleet
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
''' + UPR_AVAIL + '''
completion_reward = {
\tadd_political_power = 50
\tadd_war_support = 0.05
\tadd_stability = -0.05
\tset_country_flag = transnistria_rising
\tset_country_flag = MOL_mon_romanov_dniester_rising
\tcustom_effect_tooltip = MOL_mon_romanov_uprising_tt
\tunlock_decision_category_tooltip = MOL_transnistria_category
}'''),
 F('''id = MOL_mon_romanov_agents
icon = GFX_goal_generic_intelligence_exchange
prerequisite = { focus = MOL_mon_romanov_uprising }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_uprising
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
available = { has_country_flag = MOL_mon_romanov_dniester_rising }
completion_reward = {
\tadd_political_power = 50
\tadd_war_support = 0.05
\tset_country_flag = transnistria_agents_bonus
}'''),
 F('''id = MOL_mon_romanov_volunteers
icon = GFX_goal_generic_allies_build_infantry
prerequisite = { focus = MOL_mon_romanov_agents }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_agents
cost = 10
search_filters = { FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
available = { has_country_flag = MOL_mon_romanov_dniester_rising }
completion_reward = {
\tadd_manpower = 5000
\tadd_equipment_to_stockpile = { type = infantry_equipment amount = 1500 }
\tadd_war_support = 0.05
\tset_country_flag = transnistria_volunteers_bonus
}'''),
 F('''id = MOL_mon_romanov_reunion
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_romanov_volunteers }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_volunteers
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_ANNEXATION }
available_if_capitulated = yes
available = {
\tcountry_exists = PMR
\tPMR = { is_in_faction = no has_war = no }
}
completion_reward = {
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_transnistria_reunion }
\tMOL = { country_event = { id = transnistria_events.3 days = 1 } }
}'''),
 F('''id = MOL_mon_romanov_war_ussr
icon = GFX_focus_attack_soviet
prerequisite = { focus = MOL_mon_romanov_reunion }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_reunion
cost = 20
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tSOV = { exists = yes }
\tNOT = { has_war_with = SOV }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tSOV = { exists = no }
\t\towns_state = 192
\t}
}
completion_reward = {
\tadd_war_support = 0.15
\tadd_state_claim = 192
\tadd_state_claim = 196
\tadd_state_claim = 197
\tadd_state_claim = 137
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = SOV
\t\tgenerator = { 192 196 197 137 }
\t}
}'''),
 F('''id = MOL_mon_romanov_imperial_throne
icon = GFX_focus_rom_royal_dictatorship
prerequisite = { focus = MOL_mon_romanov_war_ussr }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_war_ussr
cost = 25
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_war_support = 0.10
\tadd_manpower = 50000
\tadd_dynamic_modifier = { modifier = MOL_imperial_throne }
}'''),
]

# ================= применяем к дереву =================
p = 'common/national_focus/moldova.txt'
s = read(p)

# (a) хвост земской линии перед маркером ГАБСБУРГОВ
m_habs = T + '\t# ==========================================================\n' + T + '\t# ЛИНИЯ ГАБСБУРГОВ'
i_habs = s.index(m_habs)
if 'MOL_mon_native_uprising' not in s:
    s = s[:i_habs] + '\n'.join(NATIVE_TAIL) + '\n' + s[i_habs:]
    print('[OK] земская линия: +4 фокуса восстания на Днестре')

# (b) замена линии Романовых целиком
m_rom = T + '\t# ==========================================================\n' + T + '\t# ЛИНИЯ РОМАНОВЫХ'
i_rom = s.index(m_rom)
end = s.rindex('\n}')
s = s[:i_rom] + '\n'.join(ROM) + s[end:]
write(p, s)
print('[OK] линия Романовых: 3 пути + большие подветки + восстание + ЕДИНСТВЕННАЯ война с СССР')

# ================= событие: косметический тег процарской ПМР =================
p = 'events/transnistria_events.txt'
s = read(p)
anchor = '\t\t\t\telse = {\n\t\t\t\t\tset_politics = {\n\t\t\t\t\t\truling_party = neutrality\n\t\t\t\t\t}\n\t\t\t\t}\n'
ins = ('\t\t\t\t# Процарские лоялисты: ПМР получает другой косметический тег\n'
       '\t\t\t\tif = {\n'
       '\t\t\t\t\tlimit = { MOL = { has_country_flag = MOL_mon_romanov_dniester_rising } }\n'
       '\t\t\t\t\tset_cosmetic_tag = PMR_tsarist_loyalists\n'
       '\t\t\t\t}\n')
if 'PMR_tsarist_loyalists' not in s:
    assert anchor in s
    s = s.replace(anchor, anchor + ins, 1)
    write(p, s)
    print('[OK] transnistria_events.1: косметический тег PMR_tsarist_loyalists при процарском флаге')
else:
    print('[--] уже есть')

# ================= цвета косметического тега =================
p = 'common/countries/cosmetic.txt'
if not os.path.isfile(p):
    write(p, '''# Цвета косметических тегов RoIMOL
# Формат как в colors.txt; применяется через set_cosmetic_tag.

PMR_tsarist_loyalists = {
\tcolor = rgb { 70 50 25 }
\tcolor_ui = rgb { 210 185 120 }
}
''')
    print('[OK] common/countries/cosmetic.txt создан (PMR_tsarist_loyalists)')
else:
    print('[--] cosmetic.txt уже есть')

# ================= локализация =================
P = 'localisation/russian/RoIMOL_focus_l_russian.yml'
s = read(P)
NEW = [
 ('MOL_mon_native_uprising', 'Земское восстание на Днестре',
  'Левый берег Днестра населён молдаванами, которых держава не спрашивала о вере и языке. Земские эмиссары готовят восстание: когда оно вспыхнет, Приднестровье встанет под знамёна господарства.'),
 ('MOL_mon_native_agents', 'Земская агентура за Днестром',
  'Старосты, священники и учителя левого берега становятся нашей сетью. Их донесения точны, а ячейки скрыты до часа восстания.'),
 ('MOL_mon_native_volunteers', 'Добровольцы господарства',
  'С берегов Прута на левый берег идут добровольцы и обозы с винтовками. Восстание получит людей и оружие, а господарство — ветеранов после победы.'),
 ('MOL_mon_native_reunion', 'Воссоединение берегов',
  'Приднестровье, отстоявшее свою республику, добровольно входит в господарство. Днестр снова внутренняя река, а не граница.'),
 ('MOL_mon_romanov_allied_path', 'Союзнический путь',
  'Двор ставит на Антанту: Лондон и Париж признают императорские претензии в обмен на гарантии и рынки. Медленнее, но с тылом из великих держав.'),
 ('MOL_mon_romanov_german_path', 'Прогерманский путь',
  'Берлин готов вооружать любого врага Москвы. Двор принимает немецкие винтовки, лицензии и инструкторов — цена: зависимость от рейхсвера.'),
 ('MOL_mon_romanov_autocracy', 'Самодержавие без хозяев',
  'Императорский двор не кланяется ни Лондону, ни Берлину: вся власть короне, опора — церковь и войско. Управление жёстче, но никто не указывает извне.'),
 ('MOL_mon_romanov_entente', 'Гарантии Антанты',
  'Двор гарантирует малые демократии Средиземноморья и Балкан, покупая их голос в пользу императорского дела. Сеть гарантий — щит от московских претензий.'),
 ('MOL_mon_romanov_allied_aid', 'Союзнические поставки',
  'Через Константинополь и Марсель идут винтовки, обмундирование и кредиты двору. Эмиграция вооружается за счёт союзников, а не казны.'),
 ('MOL_mon_romanov_allied_corps', 'Экспедиционный корпус',
  'Офицеры двора проходят школу при штабах Антанты: корпус эмиграции получает доктрину и выправку регулярной армии великих держав.'),
 ('MOL_mon_romanov_berlin_pact', 'Соглашение с Берлином',
  'Двор и рейхсвер обмениваются признанием и поставками. Немцы получают плацдарм против Москвы, двор — оружие и золото.'),
 ('MOL_mon_romanov_german_arms', 'Немецкие винтовки',
  'Эшелоны с маузерами и пулемётами разгружаются в Кишинёве. Армия эмиграции вооружена по немецким табелям.'),
 ('MOL_mon_romanov_german_officers', 'Немецкие инструкторы',
  'Офицеры рейхсвера ставят муштру и штабную работу двору. Организация войск растёт, но часть командиров смотрит на Берлин чаще, чем на корону.'),
 ('MOL_mon_romanov_uprising', 'Восстание царских лоялистов',
  'На левом берегу Днестра живут семьи офицеров и чиновников прежней империи. Двор поднимает их под императорскими знамёнами: республика, которая возникнет там, будет процарской.'),
 ('MOL_mon_romanov_agents', 'Императорская агентура',
  'Офицеры-подпольщики и старые чиновники держат сеть за Днестром. Их донесения лягут в основу часов восстания.'),
 ('MOL_mon_romanov_volunteers', 'Добровольцы эмиграции',
  'Юнкера и казаки эмиграции идут на левый берег с винтовками двора. Восстание получит кадровое ядро, а двор — преданную гвардию.'),
 ('MOL_mon_romanov_reunion', 'Воссоединение под императорским знаменем',
  'Процарская приднестровская республика, отстояв себя, передаёт себя под руку государя. Днестр становится внутренней рекой империи в изгнании.'),
 ('MOL_mon_romanov_war_ussr', 'Поход на Москву',
  'Единственная и неизбежная война двора: Советский Союз держит земли прежней империи и не признаёт корону. Цели войны — Одесса, Херсон, Николаев и Крым. Дальше только поход.'),
]
if 'MOL_mon_native_uprising:' not in s:
    if not s.endswith('\n'): s += '\n'
    s += ('\n # ==================== ЗЕЛЁНАЯ ВЕТКА v3: восстания и пути Романовых ====================\n'
          + ''.join(' %s: "%s"\n %s_desc: "%s"\n' % (k, n, k, d) for k, n, d in NEW))
    write(P, s)
    print('[OK] focus loc: +%d строк' % (len(NEW) * 2))
# удаляем осиротевшие ключи v2
for k in ['MOL_mon_romanov_south', 'MOL_mon_romanov_southern_claims']:
    import re as _re
    pat = _re.compile(r'^[ \t]*' + _re.escape(k) + r'(_desc)?:.*\n', _re.M)
    s2 = pat.sub('', s)
    if s2 != s:
        s = s2
        print('[OK] focus loc: удалён осиротевший ключ %s' % k)
write(P, s)

P = 'localisation/russian/RoIMOL_tooltips_l_russian.yml'
s = read(P)
if 'MOL_mon_romanov_uprising_tt:' not in s:
    if not s.endswith('\n'): s += '\n'
    s += (' MOL_mon_romanov_uprising_tt: "Откроет категорию решений §YТранснистрия§! (агенты → вооружение → восстание).\\n'
          'Восстание породит §YПМР§! и §Y30-дневную войну§! против владельца 834. Поскольку восстание поднято двором, республика получит косметический тег §YПриднестровское царское ополчение§! (процарские лоялисты).\\n'
          'Если ПМР удержится, фокус §YВоссоединение под императорским знаменем§! присоединит её к нам."\n')
    write(P, s)
    print('[OK] tooltips: +MOL_mon_romanov_uprising_tt')

P = 'localisation/russian/RoIMOL_countries_l_russian.yml'
s = read(P)
if 'PMR_tsarist_loyalists_neutrality:' not in s:
    if not s.endswith('\n'): s += '\n'
    s += ('\n # Процарский косметический тег ПМР\n'
          ' PMR_tsarist_loyalists_communism: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_communism_DEF: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_communism_ADJ: "Приднестровск"\n'
          ' PMR_tsarist_loyalists_neutrality: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_neutrality_DEF: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_neutrality_ADJ: "Приднестровск"\n'
          ' PMR_tsarist_loyalists_democratic: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_democratic_DEF: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_democratic_ADJ: "Приднестровск"\n'
          ' PMR_tsarist_loyalists_fascism: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_fascism_DEF: "Приднестровское царское ополчение"\n'
          ' PMR_tsarist_loyalists_fascism_ADJ: "Приднестровск"\n')
    write(P, s)
    print('[OK] countries loc: +12 ключей косметического тега')
