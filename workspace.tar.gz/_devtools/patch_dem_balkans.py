# -*- coding: utf-8 -*-
"""Патч: гарантии Балканам без Румынии, ультиматум Румынии (земли + демократизация),
«Война за Молдавию» -> нацдух на атаку/оборону против ROM, новые условия двух взаимоисключающих фокусов."""
import os, re, shutil, datetime

STAMP = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
BK = os.path.join('_devtools', 'backup_' + STAMP)

FILES = [
    'common/national_focus/moldova.txt',
    'events/MOL_democratic_events.txt',
    'common/dynamic_modifiers/ROIMOL_ideas.txt',
    'localisation/russian/RoIMOL_focus_l_russian.yml',
    'localisation/russian/RoIMOL_ideas_l_russian.yml',
    'localisation/russian/RoIMOL_tooltips_l_russian.yml',
    'localisation/russian/RoIMOL_events_l_russian.yml',
]

def read(p):
    return open(p, encoding='utf-8').read()      # BOM сохраняется как \ufeff

def write(p, s):
    open(p, 'w', encoding='utf-8', newline='').write(s)

def backup():
    for p in FILES:
        dst = os.path.join(BK, p.replace('/', '__'))
        os.makedirs(BK, exist_ok=True)
        shutil.copy2(p, dst)
    print('бэкап -> %s (%d файлов)' % (BK, len(FILES)))

# ---------- утилиты для работы с блоками ----------
def block_span(s, start_idx):
    """От индекса начала '{' (или строки с '{') возвращает (start, end_exclusive) по балансу скобок."""
    i = s.index('{', start_idx)
    depth = 0
    j = i
    while True:
        if s[j] == '{':
            depth += 1
        elif s[j] == '}':
            depth -= 1
            if depth == 0:
                return i, j + 1
        j += 1

def focus_span(s, fid):
    i = s.index('\t\tid = %s\n' % fid)
    start = s.rindex('\tfocus = {', 0, i)
    _, end = block_span(s, start)
    return start, end

def replace_key_block(text, key, new_block, start_from=0):
    """Заменяет '<key> = { ... }' (включая заголовок) на new_block. Возвращает (текст, ok)."""
    m = re.compile(r'^([ \t]*)%s = \{' % re.escape(key), re.M).search(text, start_from)
    if not m:
        return text, False
    hdr_start = m.start()
    brace = text.index('{', m.start())
    _, end = block_span(text, brace)
    indent = m.group(1)
    body = new_block.replace('@IND@', indent)
    return text[:hdr_start] + body + text[end:], True

# =========================================================
backup()
log = []

# ---------- 1. dynamic modifier ----------
p = 'common/dynamic_modifiers/ROIMOL_ideas.txt'
s = read(p)
add = '''
# === «Война за Молдавию»: боевой дух против Румынии (демократическая ветка, фокус MOL_dem_war_with_romania) ===
MOL_war_against_romania = {
\ticon = "GFX_idea_generic_morale_bonus"
\tenable = {
\t\thas_war_with = ROM
\t}
\ttargeted_modifier = {
\t\ttag = ROM
\t\tattack_bonus_against = 0.15
\t\tdefense_bonus_against = 0.20
\t}
}
'''
if 'MOL_war_against_romania = {' in s:
    log.append('dyn_modifier: уже присутствует, пропускаю')
else:
    if not s.endswith('\n'):
        s += '\n'
    s += add
    write(p, s)
    log.append('dyn_modifier: добавлен MOL_war_against_romania (+15% атака / +20% оборона против ROM, enable = has_war_with = ROM)')

# ---------- 2. фокус MOL_dem_guarantee_balkans ----------
p = 'common/national_focus/moldova.txt'
s = read(p)

new_reward = '''@IND@completion_reward = {
@IND@\tcustom_effect_tooltip = MOL_dem_guarantee_balkans_tt
@IND@\tevery_other_country = {
@IND@\t\tlimit = {
@IND@\t\t\tOR = {
@IND@\t\t\t\toriginal_tag = BUL
@IND@\t\t\t\toriginal_tag = GRE
@IND@\t\t\t\toriginal_tag = ALB
@IND@\t\t\t\toriginal_tag = YUG
@IND@\t\t\t\toriginal_tag = TUR
@IND@\t\t\t}
@IND@\t\t\tNOT = { original_tag = ROM }
@IND@\t\t\thas_government = democratic
@IND@\t\t\tis_subject = no
@IND@\t\t}
@IND@\t\tROOT = { give_guarantee = PREV }
@IND@\t\tadd_opinion_modifier = { target = ROOT modifier = MOL_democratic_cooperation }
@IND@\t}
@IND@\tadd_political_power = 50
@IND@}'''

st, en = focus_span(s, 'MOL_dem_guarantee_balkans')
blk = s[st:en]
blk2, ok = replace_key_block(blk, 'completion_reward', new_reward.replace('@IND@', '\t\t'))
assert ok, 'guarantee_balkans: completion_reward не найден'
s = s[:st] + blk2 + s[en:]
log.append('фокус MOL_dem_guarantee_balkans: список BUL/GRE/ALB/YUG/TUR (ROM исключена), добавлен тултип')

# ---------- 3. фокус MOL_dem_ultimatum_romania ----------
new_reward = '''\t\tcompletion_reward = {
\t\t\tif = {
\t\t\t\tlimit = { ROM = { has_government = democratic } }
\t\t\t\tset_country_flag = MOL_dem_ultimatum_accepted
\t\t\t\tadd_opinion_modifier = { target = ROM modifier = MOL_democratic_cooperation }
\t\t\t\tROM = { add_opinion_modifier = { target = ROOT modifier = MOL_democratic_cooperation } }
\t\t\t\tcustom_effect_tooltip = MOL_dem_romania_democratic_tt
\t\t\t}
\t\t\telse = {
\t\t\t\tadd_war_support = 0.10
\t\t\t\tcustom_effect_tooltip = MOL_dem_ultimatum_demands_tt
\t\t\t\tROM = { country_event = { id = MOL_dem_events.1 days = 1 } }
\t\t\t}
\t\t}'''
st, en = focus_span(s, 'MOL_dem_ultimatum_romania')
blk = s[st:en]
blk2, ok = replace_key_block(blk, 'completion_reward', new_reward)
assert ok, 'ultimatum_romania: completion_reward не найден'
s = s[:st] + blk2 + s[en:]
log.append('фокус MOL_dem_ultimatum_romania: при уже демократической ROM ставим флаг MOL_dem_ultimatum_accepted (иначе ветка союза недостижима); добавлен тултип требований')

# ---------- 4. фокус MOL_dem_war_with_romania ----------
new_war = '''\t\tavailable = {
\t\t\tis_subject = no
\t\t\thas_country_flag = MOL_dem_ultimatum_rejected
\t\t\thas_war_with = ROM
\t\t}
\t\tbypass = {
\t\t\tOR = {
\t\t\t\tROM = { exists = no }
\t\t\t\thas_country_flag = MOL_dem_ultimatum_accepted
\t\t\t\tAND = {
\t\t\t\t\towns_state = 79
\t\t\t\t\towns_state = 80
\t\t\t\t}
\t\t\t}
\t\t}
\t\tcompletion_reward = {
\t\t\tadd_dynamic_modifier = { modifier = MOL_war_against_romania days = 180 }
\t\t\tcustom_effect_tooltip = MOL_war_against_romania_tt
\t\t}'''
st, en = focus_span(s, 'MOL_dem_war_with_romania')
blk = s[st:en]
# меняем три блока подряд: available, bypass, completion_reward
blk2, ok1 = replace_key_block(blk, 'available', '@IND@available = {\n@IND@\tis_subject = no\n@IND@\thas_country_flag = MOL_dem_ultimatum_rejected\n@IND@\thas_war_with = ROM\n@IND@}')
assert ok1, 'war_with_romania: available не найден'
blk2, ok2 = replace_key_block(blk2, 'bypass', '@IND@bypass = {\n@IND@\tOR = {\n@IND@\t\tROM = { exists = no }\n@IND@\t\thas_country_flag = MOL_dem_ultimatum_accepted\n@IND@\t\tAND = {\n@IND@\t\t\towns_state = 79\n@IND@\t\t\towns_state = 80\n@IND@\t\t}\n@IND@\t}\n@IND@}')
assert ok2, 'war_with_romania: bypass не найден'
blk2, ok3 = replace_key_block(blk2, 'completion_reward', '@IND@completion_reward = {\n@IND@\tadd_dynamic_modifier = { modifier = MOL_war_against_romania days = 180 }\n@IND@\tcustom_effect_tooltip = MOL_war_against_romania_tt\n@IND@}')
assert ok3, 'war_with_romania: completion_reward не найден'
s = s[:st] + blk2 + s[en:]
log.append('фокус MOL_dem_war_with_romania: available = флаг отказа + has_war_with ROM; bypass исправлен (owns_state = 78 -> 79/80, добавлен флаг принятия); награда = нацдух MOL_war_against_romania на 180 дней вместо дублирующих claims/wargoal')

# ---------- 5. фокус MOL_dem_peaceful_romania ----------
st, en = focus_span(s, 'MOL_dem_peaceful_romania')
blk = s[st:en]
blk2, ok = replace_key_block(blk, 'available', '@IND@available = {\n@IND@\tROM = { exists = yes has_government = democratic }\n@IND@\thas_country_flag = MOL_dem_ultimatum_accepted\n@IND@}')
assert ok, 'peaceful_romania: available не найден'
s = s[:st] + blk2 + s[en:]
log.append('фокус MOL_dem_peaceful_romania: available теперь требует фактического принятия ультиматума (MOL_dem_ultimatum_accepted)')

write(p, s)

# ---------- 6. событие MOL_dem_events.1 ----------
p = 'events/MOL_democratic_events.txt'
s = read(p)

old_a = '''\t\tadd_stability = -0.15
\t\tadd_political_power = -100
\t\tMOL = {
\t\t\tadd_opinion_modifier = {
\t\t\t\ttarget = ROOT
\t\t\t\tmodifier = MOL_accepted_demands
\t\t\t}
\t\t}'''
new_a = '''\t\tadd_stability = -0.15
\t\tadd_political_power = -100
\t\t# Румыния принимает ультиматум: правительство падает, к власти приходят демократы
\t\tset_politics = {
\t\t\truling_party = democratic
\t\t\telections_allowed = yes
\t\t}
\t\tadd_popularity = {
\t\t\tideology = democratic
\t\t\tpopularity = 0.3
\t\t}
\t\tMOL = {
\t\t\tadd_opinion_modifier = {
\t\t\t\ttarget = ROOT
\t\t\t\tmodifier = MOL_accepted_demands
\t\t\t}
\t\t\tset_country_flag = MOL_dem_ultimatum_accepted
\t\t}'''
assert old_a in s, 'не найден блок опции A'
s = s.replace(old_a, new_a, 1)
log.append('событие MOL_dem_events.1 опция A: ROM становится демократической (set_politics + popularity 0.3) и ставит MOL флаг MOL_dem_ultimatum_accepted')

old_b = '''\t\tMOL = {
\t\t\tadd_opinion_modifier = {
\t\t\t\ttarget = ROOT
\t\t\t\tmodifier = MOL_rejected_demands
\t\t\t}
\t\t\tcreate_wargoal = {
\t\t\t\ttype = take_state_focus
\t\t\t\ttarget = ROOT
\t\t\t\tgenerator = { 78 766 79 80 }
\t\t\t}
\t\t}'''
new_b = '''\t\tMOL = {
\t\t\tadd_opinion_modifier = {
\t\t\t\ttarget = ROOT
\t\t\t\tmodifier = MOL_rejected_demands
\t\t\t}
\t\t\tset_country_flag = MOL_dem_ultimatum_rejected
\t\t\tcreate_wargoal = {
\t\t\t\ttype = take_state_focus
\t\t\t\ttarget = ROOT
\t\t\t\tgenerator = { 79 80 }
\t\t\t}
\t\t}'''
assert old_b in s, 'не найден блок опции B'
s = s.replace(old_b, new_b, 1)
log.append('событие MOL_dem_events.1 опция B: MOL получает флаг MOL_dem_ultimatum_rejected; generator цели войны сужен до 79 80 (78/766 и так наши)')

write(p, s)
print('\n'.join('[OK] ' + x for x in log))
