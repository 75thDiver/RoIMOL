# -*- coding: utf-8 -*-
"""Аудит history/* и кросс-проверка ссылок (персонажи, oob, ядра/владельцы штатов)."""
import os, re, glob

ROOT = os.getcwd()
issues, notes = [], []

def read(p):
    raw = open(p, 'rb').read()
    try:
        raw.decode('utf-8'); ok = True
    except Exception:
        ok = False
    return ok, raw

def strip_comments(t):
    t = re.sub(r'#.*', '', t)
    return t

print("=== HISTORY: скобки / BOM / CRLF / UTF-8 ===")
for p in sorted(glob.glob("history/**/*.txt", recursive=True)):
    ok, raw = read(p)
    t = raw.decode('utf-8-sig')
    clean = strip_comments(t)
    ob, cb = clean.count('{'), clean.count('}')
    bom = raw.startswith(b'\xef\xbb\xbf')
    crlf = b'\r\n' in raw
    print("  %-42s braces %3d/%-3d %-4s BOM=%-3s CRLF=%-5s UTF8=%s"
          % (p, ob, cb, 'OK' if ob == cb else '!!!', bom, crlf, ok))
    if ob != cb:
        issues.append("%s: дисбаланс скобок %d/%d" % (p, ob, cb))
    if not ok:
        issues.append("%s: не UTF-8" % p)
    if not bom:
        notes.append("%s: нет BOM" % p)

print("\n=== ШТАТЫ ===")
for p in sorted(glob.glob("history/states/*.txt")):
    t = strip_comments(open(p, encoding='utf-8-sig').read())
    sid = re.search(r'\bid\s*=\s*(\d+)', t)
    nm = re.search(r'\bname\s*=\s*"?([A-Za-z0-9_]+)"?', t)
    mp = re.search(r'\bmanpower\s*=\s*(\d+)', t)
    cat = re.search(r'\bstate_category\s*=\s*(\w+)', t)
    owner = re.search(r'\bowner\s*=\s*(\w+)', t)
    cores = re.findall(r'\badd_core_of\s*=\s*(\w+)', t)
    claims = re.findall(r'\badd_claim_by\s*=\s*(\w+)', t)
    vp = re.findall(r'\b(\d{3,5})\s+(\d+)\s*(?=\n|\})', t)
    res = re.findall(r'\b(\w+)\s*=\s*(\d+)\s*', t.split('resources')[1]) if 'resources' in t else []
    print("  %s: id=%s name=%s manpower=%s cat=%s owner=%s cores=%s claims=%s res=%s"
          % (os.path.basename(p), sid.group(1) if sid else '?', nm.group(1) if nm else '?',
             mp.group(1) if mp else '?', cat.group(1) if cat else '?',
             owner.group(1) if owner else '-', cores, claims, res))
    print("      victory_points блоки: %d; buildings: %s"
          % (t.count('victory_points'), re.findall(r'(\w+)\s*=\s*(\d+)', t.split('buildings')[1][:200]) if 'buildings' in t else '-'))

print("\n=== СТРАНЫ (history/countries) ===")
for p in sorted(glob.glob("history/countries/*.txt")):
    t = strip_comments(open(p, encoding='utf-8-sig').read())
    chars = re.findall(r'\brecruit_character\s*=\s*(\w+)', t)
    oob = re.findall(r'\boob\s*=\s*"?([^"\n]+)"?', t)
    pol = re.search(r'ruling_party\s*=\s*(\w+)', t)
    tags = re.findall(r'\bset_autonomy\s*=|puppet\s*=', t)
    print("  %s: oob=%s ruling_party=%s recruit_character=%d шт."
          % (os.path.basename(p), oob, pol.group(1) if pol else '?', len(chars)))
    print("      персонажи: %s" % (", ".join(chars) if chars else "-"))
    globals().setdefault('ALLCHARS', []).extend(chars)

print("\n=== OOB (history/units) ===")
for p in sorted(glob.glob("history/units/*.txt")):
    t = strip_comments(open(p, encoding='utf-8-sig').read())
    tmpl = re.findall(r'division_template\s*=\s*\{[^{}]*name\s*=\s*"([^"]+)"', t)
    regt = t.count('regiments')
    divs = re.findall(r'\bdivision\s*=\s*\{', t)
    names = re.findall(r'name\s*=\s*"([^"]+)"', t)
    print("  %s: division_template=%d (%s), division=%d" % (os.path.basename(p), len(tmpl), tmpl, len(divs)))
    print("      все name=: %s" % names[:20])

print("\n=== ИТОГ ===")
print("ПРОБЛЕМ: %d" % len(issues))
for x in issues:
    print("  [P] " + x)
print("ЗАМЕТОК: %d" % len(notes))
for x in notes[:20]:
    print("  [N] " + x)
