# Страны (Countries) — конспект для RoIMOL

Источники:
- https://hoi4.paradoxwikis.com/Countries
- https://hoi4.paradoxwikis.com/Releasable_countries/Europe#Moldova (секция 31, получена через API `action=parse&section=31`)
- https://hoi4.paradoxwikis.com/Country_creation
- https://hoi4.paradoxwikis.com/Cosmetic_tag_modding

## Базовые факты
- В игре **344 страны** (без formable), из них **99 существуют на старте 1936**.
- Каждая страна принадлежит одной из 4 идеологий; **нейтралитет (non-aligned) почти невозможно поднять без моддинга**.
- **Тег — трёхбуквенный код**, не зависит от локализации и идеологии; консольные команды работают по тегу.
- Страны, созданные после старта (гражданская война, коллаборационистские правительства), получают теги вида `D##`.
- **Косметические теги — исключение**: не требуют регистрации и **не ограничены 3 буквами**.

## Major vs minor (важно для «региональной сверхдержавы»)
- Фракция капитулирует только когда капитулируют **все её major-страны**.
- Major в 1936: GER, ITA, JAP, SOV, FRA, ENG, USA.
- Как стать major: (а) возглавить фракцию — мгновенно; (б) иметь ≥ `MAJOR_MIN_FACTORIES` фабрик и войти в топ `MIN_MAJOR_COUNTRIES` по фабрикам, либо иметь больше `ADDITIONAL_MAJOR_COUNTRIES_IC_RATIO`% от среднего у топа. Проверка раз в месяц; во время войны статус не теряется.
- Бонусы major: доступ к части событий/фокусов/решений других стран, скидки в мирных конференциях, сложнее стать целью coup-операции (LaR), меньше мировой напряжённости при оправдании войны против него.
- **Импликация:** `MOL_red_unification_of_balkans` / `MOL_balkan_union` / `MOL_peoples_republic` логично делать major-страной (лидер фракции = автоматически major) — это открывает доступ к ванильным «major-only» событиям и меняет поведение ИИ.

## ⚠ КЛЮЧЕВОЕ: Moldova — ванильная releasable-страна, тег MOL занят ваниллой
Из `Releasable countries/Europe#Moldova`:
- Столица: **Chișinău**; правительство: **Democratic**; фракции нет; выборы раз в 4 года, следующие — январь 1940.
- Ванильные партии и популярность: Democratic **55%**, Communist **30%**, Fascist **1%**, Non-Aligned **14%**.
- Ванильные названия страны по идеологиям: Democratic → «Moldova», Communist → «Moldavian Socialist Republic», Fascist → «Bessarabia», Non-Aligned → «Moldavia».
- Лидеры партий — Generic (своих персонажей у ванильной Молдовы нет).

**Выводы для проекта:**
1. Тег `MOL` **уже зарегистрирован ванилью** (releasable) → регистрировать его в `common/country_tags/` моду НЕ нужно. Прежняя претензия «тег MOL не зарегистрирован» — снята.
2. Значения в `history/countries/MOL - Moldova.txt` (`democratic 55 / fascism 1 / communism 30 / neutrality 14`, `election_frequency = 48`) **побайтово совпадают с ванильной releasable-Молдовой** → файл скопирован с ванили. Имя файла `MOL - Moldova.txt` совпадает с ванильным, значит переопределение сработает.
3. Ванильные loc-ключи `MOL_democratic`, `MOL_communism`, `MOL_fascism`, `MOL_neutrality` (+`_DEF`, `_ADJ`) существуют; наш `RoIMOL_countries_l_russian.yml` их перекрывает («Бессарабские территории в Румынии» / «БТвР» и т.д.) — это штатный механизм (локализация мода грузится после ванильной).
4. У ванильной Молдовы **нет собственного фокус-дерева** (в таблице releasable-стран у неё нет секции «National focus», в отличие от Montenegro/Bosnia) → наше `default = yes` дерево `moldova_focus` с `country = { factor = 0 modifier = { add = 10 tag = MOL } }` корректно перехватывает MOL и не навязывается остальным.
5. **Риск:** раз MOL — ванильная releasable-страна, её может освободить Румыния/СССР через стандартное «Release nation» в мирной конференции. Наша `history/countries/MOL - Moldova.txt` тогда применится к освобождённой стране (автономия от ROM уже задана в файле через `set_autonomy`) — надо проверить, не конфликтует это со стартовым сценарием, где MOL существует с 1936 как субъект Румынии.
6. `PMR` — по поиску вики **0 упоминаний** → тег свободен (Transnistria/PMR как releasable-стран в ванили нет). Регистрация `PMR = "countries/Transnistria.txt"` в `common/country_tags/01_ROIMOL_countries.txt` корректна.

## Косметические теги (как правильно)
- Объявлять в `country_tags` **не нужно**; ставятся эффектом `set_cosmetic_tag = <TAG>`, снимаются `set_cosmetic_tag = ""` (или новым тегом — страна может иметь только один косметический тег).
- **Цвета** — только в `common/countries/cosmetic.txt`, формат как в `colors.txt`:
  ```
  COSMETICTAG = {
      color = rgb { 2 10 222 }
      color_ui = rgb { 255 255 155 }
  }
  ```
  Отдельные `common/countries/<COSMETICTAG>.txt` движком **не читаются**.
- **Флаги**: 3 TGA (82×52, 41×26, 10×7), 32-bit, без RLE, origin bottom-left, в `gfx/flags/` и подпапках. Имя: `COSMETICTAG_ideology.tga`, фолбэк `COSMETICTAG.tga`.
  **Важно:** фолбэк НЕ имеет приоритета над идеологическим флагом базовой страны — если у MOL есть `MOL_democratic.tga`, то косметический тег без `Free_MOL_democratic.tga` покажет флаг MOL. → **для каждого косметического тега нужны идеологические флаги** (минимум для тех идеологий, в которых тег применяется).
- **Локализация**: `<COSMETICTAG>_<ideology>`, `_DEF`, `_ADJ` — у нас для всех 6 тегов есть ✓.
- Также косметический тег может переопределять имена/портреты случайных персонажей и модели войск (сущностей).

## Наш набор тегов и что с ним делать
| Тег | Тип | Регистрация | Цвет | Флаги |
|---|---|---|---|---|
| `MOL` | реальный (ванильный releasable) | ваниль | ванильный `common/countries/MOL.txt` | ванильные + наши override |
| `PMR` | реальный (создаётся событием) | `country_tags/01_ROIMOL_countries.txt` ✓ | `common/countries/Transnistria.txt` ✓ (нет `color_ui`) | нужны `PMR*.tga` |
| `Free_MOL` | косметический | не нужна | → перенести в `cosmetic.txt` | `Free_MOL_<ideology>.tga` |
| `MOL_Bessarabian_Tinut` | косметический | не нужна | отсутствует | нужны |
| `ROM_MOL_autonomic_state` | косметический | не нужна | отсутствует | нужны |
| `MOL_balkan_union` | косметический | не нужна | → перенести в `cosmetic.txt` | нужны |
| `MOL_moldavian_ssr` | косметический (пока не применяется) | не нужна | → перенести в `cosmetic.txt` | нужны |
| `MOL_peoples_republic` | косметический | не нужна | → перенести в `cosmetic.txt` | нужны |
