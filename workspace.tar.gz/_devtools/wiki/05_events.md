# События (Events) — конспект для RoIMOL

Источники:
- https://hoi4.paradoxwikis.com/Events (вер. 1.17) — оглавление всех файлов `events/`
- https://hoi4.paradoxwikis.com/Romanian_events (вер. 1.16, `events/Romania.txt`) — прочитан полностью
- https://hoi4.paradoxwikis.com/Soviet_events (+ WtT, NSB, NSB 2) — **полный список не читал** (страницы огромные); взята цепочка, относящаяся к Бессарабии, через перекрёстные ссылки Romanian events и поиск по вики. Помечено как пробел.

## Структура файлов событий в ванили
`Events` — это индекс: отдельно перечислены **generic-файлы** и **национальные**. Полезные нам:
- Generic: `Generic events`, `Political events`, `News events 1..4` (id 1-100 / 101-200 / 201-300 / 301-400), `Capitulation events`, `Decision events`, `Election events`, `Low Stability events`, `War justification events`, `Border conflict events`, `Occupation events` (LaR), `NATO events`, `Naval treaty events`, `Exiled government events`, `Agent events` (LaR), `Espionage operation events` (LaR).
- Национальные, релевантные RoIMOL: `Romanian events`, `Romanian events DoD`, `Soviet events`, `Soviet events WtT`, `Soviet events NSB`, `Soviet events NSB 2`, `Bulgarian events` (+BftB), `Greek events` (+BftB), `Turkish events` (BftB), `Yugoslavian events` (+DoD), `Hungarian events` (+DoD 1/2), `Italian events` (+BBA), `German events` (+WtT/MtG/GD), `British events` (+WtT/MtG), `French events` (+LaR), `Swiss events` (BBA — пригодится для «швейцарской модели» демократической ветки).

## ⚠ Ключевая цепочка: ультиматум по Бессарабии (штат 78)
**`romania.1` — «The Soviet Union Demands Bessarabia»** (`events/Romania.txt`)
- Текст: советские войска сосредоточены у границы, дипломаты требуют передать **всю Бессарабию**; немцы не вмешаются из-за секретного протокола пакта.
- **Триггерится только** из: советского события **`soviet.30` «Demand Bessarabia»** либо по завершении фокуса **`SOV_claim_on_bessarabia`**.
- Опция A «No. It is hopeless.» → СССР получает **`soviet.4` «Romania Surrenders Bessarabia»** через 1 день; ставится флаг **`bessarabia_ceded`**.
- Опция B «Yes! We will not give up our territory without a fight!» → СССР получает **`soviet.5` «Romania Refuses Our Demands»** через 1 день и **цель войны Conquer на штат Bessarabia (78)** против Румынии.
- Тайминг по стратегическим гайдам вики: **середина 1940**. Если отказать — СССР получает только war goal (не автоматическую войну).
- Прочие румынские события файла: `romania.2` и `romania.3` — Второй Венский арбитраж (частичная/полная Трансильвания; флаги `second_vienna_accepted_north` / `second_vienna_accepted_all`; отказ → claims на 76, 83, 84 + `germany.21`), `romania.4` — Германия оставляет Трансильванию румынам, `romania.5` — Договор в Крайове (Добруджа (77) уходит Болгарии → `bulgaria.1`/`bulgaria.2`).

### Что это значит для RoIMOL
1. **Наш `moldavia.9` «Судьба Бессарабии в наших руках»** — это зеркало `romania.1` для автономии: Москва требует, Бухарест передаёт решение Молдавскому Собранию. Логика опций (уступить / воевать) должна давать те же последствия, что и ваниль: передача штатов 78 (+766) и/или Conquer-CB на 78 для SOV.
2. **Локализация `romania.1.c` и `romania.1.d`** в `RoIMOL_events_l_russian.yml` — это **переопределение ванильного `romania.1`** (добавлена третья опция «Это дело центра» и переписан текст). Чтобы это сработало, нужен файл `events/Romania.txt` **в моде с тем же именем** (переопределение ванили идёт по точному совпадению пути и имени). Файл пока не передан — он в списке недостающих (`add_namespace = romania` нигде не найден).
   **Риск:** переопределяя `events/Romania.txt`, нужно сохранить `romania.2 … romania.5`, иначе сломаются Венский арбитраж и Крайова.
3. **Ванильный флаг `bessarabia_ceded`** — удобная точка сопряжения: по нему можно ловить «Советы получили Бессарабию» и запускать нашу ветку (например, `MOL_soviet_events`, судьба ПМР, `MOL_ssr_status`).
4. **Фокус `SOV_claim_on_bessarabia`** — вторая точка входа: если ИИ-СССР пойдёт по нему, `romania.1` (или наш `moldavia.9`) сработает без `soviet.30`. Значит наш триггер не должен зависеть только от `soviet.30`.
5. Штат **78 = Bessarabia** — совпадает с нашей `history/states/78-Bessarabia.txt` ✓.

## Пробелы (зафиксированы честно)
- Полный список `Soviet events` (id и опции `soviet.4`, `soviet.5`, `soviet.30`) не вычитан — при необходимости догружу конкретные секции страницы через API (`action=parse&section=N`), чтобы не тянуть весь объём.
- `Soviet events NSB / NSB 2 / WtT` — не читаны; там живут события по Прибалтике и «советизации», потенциально полезные для ветки вхождения в СССР (`MOL_soviet.1…3`, `MOL_soviet_news.1`).
