# Механики и дипломатия — конспект для RoIMOL

Источники:
- https://hoi4.paradoxwikis.com/Mechanics (это **страница-оглавление**: таблицы ссылок по группам механик, вер. 1.8)
- https://hoi4.paradoxwikis.com/Diplomacy (вер. 1.9)
- https://hoi4.paradoxwikis.com/Puppet (вер. 1.14)

## Mechanics: что за страница
`Mechanics` — индекс ключевых концепций, не источник чисел. Группы: **Politics** (Ideology, Faction, National focus, Ideas, Government, Puppet, Diplomacy, World tension, Civil war, Occupation, Balance of power), **Production** (Trade, Production, Construction, Equipment, Fuel, MIO, International market), **Research** (все ветки технологий, доктрины, Special project, Scientist), далее — военные и прочие.
Практический смысл: отсюда прыгать на профильную страницу. Для RoIMOL критичны **Puppet**, **Diplomacy**, **Faction**, **Occupation**, **Civil war**.

## Дипломатия: базовые принципы
- Дипломатия **билатеральна** (один на один); исключение — фракция: все её члены вместе вступают в оборонительные войны и могут быть позваны в наступательные.
- Дипломатия **несимметрична**: мнения и шансы принятия предложений независимы для каждой стороны.
- Мнение улучшают: общая фракция, общая идеология, гарантии, торговля, «Improve relations».

### Diplomatic actions (требования и стоимость)
| Действие | Требования | Как отменяется |
|---|---|---|
| Declare war | нужна war goal | война идёт >6 мес., ты лидер фракции, ты проигрываешь, war score победителя ≥50% |
| Justify war goal | цель не союзник; стоимость в ПП растёт с World Tension, модифицируется subversive activities; минимум `MIN_WARGOAL_JUSTIFY_COST` | — |
| **Guarantee independence** | та же идеология; стоимость `GUARANTEE_COST` ПП **+ столько же за каждую уже гарантированную страну**; нужен порог World Tension | цель не должна гарантировать тебя |
| Call to arms | та же фракция | не отменяется |
| Ask/Offer military access | цель должна согласиться; членам фракции выдаётся автоматически | отозвать можно, если на её территории нет твоих войск |
| Ask/Offer docking rights | то же; расширяют морскую дальность | — |
| **Improve relations** | не быть в войне с целью; старт `BASE_IMPROVE_RELATION_COST` ПП + `..._SAME_IDEOLOGY_GROUP_MAINTAIN_COST`/день при той же идеологии, `..._DIFFERENT_IDEOLOGY_GROUP_MAINTAIN_COST`/день при разной; потолок **+100** | — |
| Send Attaché | цель воюет; `BASE_SEND_ATTACHE_COST` ПП + `BASE_SEND_ATTACHE_CP_COST` CP на поддержание | — |
| Non-aggression pact | цель соглашается | нельзя разорвать без общей границы и в первые `NAP_UNBREAKABLE_MONTHS` мес.; далее по соотношению сил на границе (`NAP_BREAK_FORCE_BALANCE_1/2/3`); истекает через `NAP_EXPIRY_MONTHS`. **Если объявить войну третьей стране, которую гарантирует твой NAP-партнёр, он всё равно вступит против тебя** |

**Важно про гарантии:** если страна гарантирует и агрессора, и жертву — она **не вступает автоматически**.
→ Для `MOL_dem_guarantee_independence` / `MOL_dem_guarantee_balkans`: гарантия требует **той же идеологии** у цели и **порога World Tension**; демократическая Молдова не может гарантировать недемократов штатным действием. Плюс растущая цена (25, 50, 75…) — «завалить гарантиями все Балканы» не выйдет без бонусов к стоимости.

### Прочие стоимости из раздела Government (см. также 03_government.md)
- Justify «Conquest»: **50 ПП**, +5 за цель с нацдухом Neutral Foreign Policy, **+10 ПП за каждый дополнительный штат**; «Retake core state»: **25 ПП**.
- Guarantee: **25 ПП**, +25 за каждую следующую.
- Improve relations: **10 ПП** старт, **0.2 ПП/день** при той же идеологии, **0.4 ПП/день** при разной.

## Puppet / автономия (ядро механики MOL↔ROM)
- При создании марионетки её правительство заменяется на установленное сюзереном **и совпадающее по идеологии сюзерена**.
- Сюзерен может звать марионеток в свои войны; в мирной конференции марионетки **не могут сами выдвигать требования** (кроме высоких уровней — доминионы, сателлиты).
- **Марионетка не может сама делать марионеток.**
- Если сюзерен капитулирует — марионетки капитулируют автоматически, если только они не во фракции с некапитулировавшим major'ом. Если сюзерен капитулировал, но во фракции марионетки остались major'ы — марионетка получает очки автономии.
- Победители могут «отцеплять» марионеток от сюзерена.
- **Коммунисты получают −35% к стоимости создания марионеток** (и −10% в мирных сделках) → напрямую полезно для красной ветки `MOL_red_*` и Балканской федерации.

### Выгоды сюзерена (числа)
- Торговля с марионеткой по льготному курсу: **Integrated Puppet / Puppet — 80 loads ресурса на фабрику (скидка 90%)**, **Colony — 16 loads (50%)**, **Dominion — 10 loads (25%)**.
- `Extra trade for overlord` начисляется поверх торгового закона марионетки и применяется к **не экспортированной** части: пример — 200 стали, Free Trade (80% → 160), бонус +25% (Dominion) даёт 170 доступных сюзерену. **Integrated Puppet позволяет выгребать все ресурсы даже при Closed Economy у марионетки.**
- **Integrated Puppet, Reichskommissariat/Reichsprotectorate, Imperial Associate/Protectorate отдают сюзерену долю гражданских фабрик (включая НПЗ) и большую долю военных**; верфи не затрагиваются.
- Запрос лицензионного производства снаряжения марионетки — со скидкой или бесплатно, плюс бонус к исследованию этого снаряжения.
- «Request control over troops» — дивизии марионетки переходят сюзерену.
- **Колониальные дивизии сюзерена используют manpower марионетки: Colony 70%, Puppet 90%, Integrated Puppet 100%**; шаблоны берутся из списка марионетки.
- Ленд-лиз: у марионетки и сюзерена **раздельные кулдауны**; сюзерен может просить ленд-лиз у марионетки, чтобы выкачать её склады.
- Марионетке не нужен гарнизон → экономия manpower и оружия; марионетка может слать гарнизоны сюзерену.
- Марионетки дают меньше World Tension, чем аннексия → меньше риск иностранного вмешательства.
- Марионетки сохраняют свой флот.
- Часть уровней автономии передаёт сюзерену часть war score.
- С LaR: Satellites, Dominions, Imperial Subjects, Supervised States могут давать шпионов spymaster'у.
- Марионетка и сюзерен могут обмениваться технологиями (tech sharing / equipment licensing).
- Снабжение: дивизии сюзерена на территории марионетки снабжаются из её логистики; недоукомплектованные дивизии сюзерена вооружаются за счёт марионетки **без роста её автономии**.

### Уровни автономии (script-id)
Линейка (по убыванию свободы): `autonomy_free` → `autonomy_dominion` → `autonomy_colony` → `autonomy_puppet` → `autonomy_integrated_puppet`; фашистские: `autonomy_satellite`, `autonomy_reichsprotectorate`, `autonomy_reichskommissariat`; японские: `autonomy_imperial_subject`, `autonomy_imperial_protectorate` (+ personal union).
Подтверждено локальной базой эффектов: `set_autonomy = { target = GBR autonomy_state = autonomy_puppet freedom_level = 0.5 end_wars = yes }`; в документации присутствуют токены `autonomy_puppet`, `autonomy_free`, `autonomy_score`, `autonomy_ratio`, `autonomy_progress_ratio`, `autonomy_gain*`.
**`autonomy_integrated_territory` в документации отсутствует** → в `history/countries/MOL - Moldova.txt` почти наверняка нужен `autonomy_integrated_puppet`. *(Проверено по базе эффектов скиллов и по названию уровня «Integrated Puppet» на вики; финальная сверка — `common/autonomous_states/` твоей версии игры.)*

### Аргументы автономии (Autonomy state modding)
`id`, `default` (используется при «puppet» в мирных сделках и в эффекте puppet), `is_puppet`, `use_overlord_color`, `min_freedom_level` (порядок уровней + сколько очков автономии нужно для смены: разница freedom-уровней × 5000), `manpower_influence`, `rule` (yes/no по списку game rules).

## Faction
- Фракция — единственный «небилатеральный» институт: совместное вступление в оборонительные войны, приглашение в наступательные.
- Лидер фракции автоматически становится **major** (см. 01_countries.md).
- → Для `MOL_red_balkan_communist_federation` (`create_faction` + приглашения) и `MOL_dem_join_allies` (`join_faction`) это ключевая механика; лидерство даёт major-статус и право диктовать требования марионеткам.
