# Фокус-дерево: точная семантика prerequisite / bypass / available
## + ЭРРАТА к скиллам eightman999/hoi4-modding-skills

Источник: https://hoi4.paradoxwikis.com/National_focus_modding (вер. 1.13), раздел «Interaction with other focuses».

## ⚠ ЭРРАТА: в скиллах написано НАОБОРОТ
`_devtools/hoi4-modding-skills/skills/hoi4-nf-creator/references/nf_structure.md:128-144` утверждает:
- «Multiple Prerequisites (OR logic)» = два отдельных блока `prerequisite`;
- «Multiple Prerequisites (AND logic)» = два `focus =` внутри одного блока.

**Это неверно.** По официальной вики:
- **`prerequisite = { focus = A focus = B }` → OR** («At least one focus within a prerequisite has to be completed to mark the prerequisite as true»);
- **два отдельных блока `prerequisite` → AND** («each prerequisite must be completed to take the focus»).

Запомнить так: *один блок = одно требование; внутри блока — варианты (OR); несколько блоков = все сразу (AND).*

Проверено на нашем дереве: `MOL_dem_liberate_transnistria` имеет
```
prerequisite = { focus = MOL_dem_war_with_romania focus = MOL_dem_peaceful_romania }   # OR: одна из двух взаимоисключающих веток
prerequisite = { focus = MOL_dem_volunteers_for_democracy }                             # AND: плюс этот фокус
```
→ конструкция корректна, дедлока нет. Если бы было наоборот (как в скиллах), фокус был бы недостижим никогда, поскольку его предки `mutually_exclusive`.

**Правило работы:** при любых сомнениях в семантике — приоритет у вики Paradox, скиллы eightman999 используются как шпаргалка и проверяются. Расхождения фиксировать здесь.

## Ограничение системы prerequisite
Ви explicitly: система **не выражает** произвольную логику вида `A ∨ (B ∧ C)` и любое отрицание. Обходной путь — поставить OR в prerequisite, а тонкие условия перенести в `available = { has_completed_focus = … }` с `custom_trigger_tooltip` для понятности игроку.

## Прочие факты о focus_tree (из той же страницы)
- `id` у дерева обязателен; **совпадение id двух деревьев = ошибка**.
- `country = { … }` — MTTH-блок выбора дерева; **вычисляется до старта игры и практически никогда не пересчитывается**. Берётся дерево с наибольшим счётом; `factor = 0` + `modifier = { add = N tag = MOL }` — наш случай.
- **`default = yes` должен быть ровно один на всю игру** (в моде + ваниль). Наше дерево — единственное в `common/national_focus/` ✓.
- `reset_on_civilwar` — эффект не определён авторами вики; реальное поведение фиксировано: оригинальная страна продолжает своё дерево; повстанцу дерево пересчитывается по `country = { … }`; если дерево совпало — все завершённые фокусы оригинала проставляются повстанцу (включая прогресс текущего), иначе прогресс теряется.
- `shared_focus = TAG_focusname` — **несуществующий фокус здесь крашит игру при загрузке в главное меню**.
- `continuous_focus_position = { x = … y = … }` — в пикселях (дефолт x=50, y=1000); при 0/0 или отсутствии — сброс к дефолту.
- `initial_show_position` — либо `focus = TAG_…`, либо `x/y` (1 единица x = 96 px, 1 единица y = 130 px), поддерживает `offset = { x y trigger = { … } }`.
- `focus = { … }` **обязан** быть внутри `focus_tree = { … }`; иначе в error.log «focus is an unexpected token».
- **ID фокуса:** префикс тега не обязателен, но настоятельно рекомендован — одинаковые id в разных деревьях ломают линии prerequisite и эффекты `complete_national_focus` / `has_completed_focus`.
- **Позиционирование:** `relative_position_id` предпочтителен; рекурсия (фокус относительно самого себя или друг друга) **может крашить игру**; указанный фокус обязан быть в том же дереве.
- `offset = { x y trigger = { … } }` применяется **в момент загрузки дерева**; обновить в сессии можно эффектом `mark_focus_tree_layout_dirty`.

## Локализация фокусов (та же страница)
- Ключ имени = id фокуса, описание = `id` + `_desc`; файлы `localisation/<lang>/*_l_<lang>.yml` **в кодировке UTF-8-BOM**.
  → Подтверждает нашу находку: во всех 9 `RoIMOL_*_l_russian.yml` BOM отсутствует, это надо чинить.
- Вики рекомендует **создавать новые loc-файлы вместо перезаписи ванильных** (легче поддерживать при обновлениях). Наш подход (`RoIMOL_*`) соответствует; исключение — намеренные переопределения (`romania.1.c/.d`, ванильные имена стран MOL).
- `shortcut = { name = lockey target = focus_id scroll_wheel_factor = 0..1 trigger = { … } }` — кнопки навигации в левом нижнем углу дерева. Удобно для нашего дерева на 175 фокусов (например, быстрые переходы к «Бессарабской политике», ветке автономии и трём идеологическим веткам).
- `inlay_window` (`common/focus_inlay_windows/*.txt`) — встраиваемые GUI-окна в дерево; объявляется внутри дерева через `inlay_window = { id = … position = { x = … y = … } }`. Потенциальный носитель для шкалы `rom_mol_trust` прямо в дереве.
