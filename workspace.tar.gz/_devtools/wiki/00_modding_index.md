# HOI4 Wiki — Категория «Modding»: карта документации

Источник: https://hoi4.paradoxwikis.com/Category:Modding (получено через API `list=categorymembers`, 54 страницы).
Это справочник-указатель: куда смотреть под конкретную задачу RoIMOL.

## База / структура
| Страница | Зачем нам |
|---|---|
| Modding | общий вход, структура мода |
| Mod structure | раскладка папок, что грузится и в каком порядке |
| Mods | `.mod`-дескриптор, `path`, `dependencies` |
| Troubleshooting | error.log, типовые ошибки |
| Defines | `common/defines/*.lua` — глобальные константы |
| Data structures | как движок хранит объекты |
| Console commands | отладка (`tmax`, `focus`, `decision`, `autonomy`) |
| Nudger | правка карты без ручного редактирования |

## Страна и территория
| Страница | Зачем нам |
|---|---|
| Country creation | тег, `common/countries/*.txt`, история, флаг, локализация |
| Cosmetic tag modding | **косметические теги RoIMOL** (Free_MOL, MOL_Bessarabian_Tinut, ROM_MOL_autonomic_state, MOL_moldavian_ssr, MOL_peoples_republic, MOL_balkan_union) |
| Autonomy state modding | **уровни автономии MOL под ROM**; аргументы `id`, `default`, `is_puppet`, `min_freedom_level`, `manpower_influence`, `rule`, `use_overlord_color` |
| State modding | история штатов 78 / 766 / 834, переопределение ванильных файлов |
| Map modding | провинции, supply areas |
| Supply areas modding, Strategic region modding | снабжение Приднестровья/Бессарабии |
| Building modding | бункеры, фабрики, порты (фокусы `MOL_bessarabia_reform_*`, `MOL_dem_build_fortifications`) |
| Resources modding | `MOL_bessarabia_reform_resources`, `MOL_ind_resource_survey` |
| Namelist modding | `common/names/01_ROIMOL_names.txt` |

## Скриптинг
| Страница | Зачем нам |
|---|---|
| National focus modding | дерево `moldova_focus` |
| Decision modding | категории/решения/миссии (`*_thirty_days_of_fire`) |
| Event modding | все `events/*.txt` |
| Idea modding | `common/ideas/` (у нас — конфликтует с dynamic modifiers) |
| Modifiers / List of modifiers | валидные токены для dynamic_modifiers |
| Effect / Triggers / Scopes | полный набор скриптовых команд |
| On actions | белый мир, капитуляция, оккупация → `MOL_white_peace_done` |
| Ideology modding | идеологические подтипы (для княжества/народной республики) |
| Faction modding | Балканская Коммунистическая Федерация |
| Technology modding, Doctrine modding, Equipment modding | бонусы `MOL_*_doctrine_bonus` |
| Division modding, Unit modding | шаблоны «Moldavian Militia», «Moldavian Rebels», «Ополчение ПМР», «International Brigade» |
| Character modding | `common/characters/MOL.txt`, лидеры трёх веток |
| Portrait modding, Graphical asset modding | `GFX_MOL_LGOV`, `GFX_grigore_cazacliu`, `GFX_ion_inculet`, `GFX_focus_MOL_resistance` |
| Interface modding, Scripted GUI modding, Font modding | свой GUI (шкала `rom_mol_trust`) |
| Localisation | `localisation/russian/RoIMOL_*.yml`, BOM, `:0` |
| Balance of power modding | возможная альтернатива переменной `rom_mol_trust` |
| Intelligence agency modding | `MOL_securitate_lar` |
| Military industrial organization modding | MIO (не используется) |
| AI modding / AI focuses | поведение ИИ на наших фокусах/решениях |
| Bookmark modding | стартовые даты |
| Music modding, Sound modding, Particle modding, Posteffect modding, Entity modding | косметика |
| Achievement modding | отключение ачивок (для мода не критично) |

## Рабочее правило для RoIMOL
Перед любой новой механикой смотреть в顺序: `Modifiers`/`List of modifiers` → `Effect`/`Triggers` → профильная страница (`Decision modding`, `National focus modding`, `Event modding`, `Autonomy state modding`, `Cosmetic tag modding`).
Локальный офлайн-аналог части этих данных: `_devtools/hoi4-modding-skills/docs/` (`01_effects/effects.json` — 439 эффектов, `04_triggers/triggers.json` — 495 триггеров, `00_coding_contexts/*`).
