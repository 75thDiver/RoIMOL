# Портреты лидеров в HOI4: как сделано у нас и как сделать детерминированно

Источники: https://hoi4.paradoxwikis.com/Character_modding (вер. 1.12), https://hoi4.paradoxwikis.com/Portrait_modding (вер. 1.5), https://hoi4.paradoxwikis.com/Cosmetic_tag_modding.

## Правило движка (ключевое)
> «If there is no valid portrait definition for a role, a random pair of small-large portraits will be created for the role from the possible selection for the country/cosmetic tag in the `portraits/*.txt` files»

То есть **если у персонажа нет блока `portraits`**, игра сама подберёт пару ванильных портретов (small + large) из пула `common/portraits/*.txt` для нашего тега/косметического тега. Это гарантированно ванильный портрет и гарантированно **не «?»**.

Дополнительно: «If the name or the portrait are not defined, **gender** is used to automatically generate them» → поэтому у новых монархов задан `gender = male`.

Ещё два факта из вики:
- Портрет назначается **после выбора страны** (из-за косметических тегов), поэтому в меню выбора страны персонаж без портрета может отображаться силуэтом — это норма.
- Если ссылка на `spriteType` неверна или `texturefile` неправилен — игра **молча подставит случайный портрет**, а не «?». То есть битый спрайт у лидера не критичен (в отличие от иконок фокусов).
- Для армейских командиров нужен и small-портрет; альтернатива — объявить спрайт с суффиксом `_small`.

## Как сделано у нас (3 монарха зелёной ветки)
```
	# === Монархи трёх династий (вымышленные; портреты генерируются игрой из ванильного пула) ===
	MOL_Mircea_Bogdan_Voda = {
		name = MOL_Mircea_Bogdan_Voda
		gender = male
	}
```
`portraits` намеренно отсутствует → ванильный случайный европейский портрет. Имя берётся из loc-ключа `MOL_Mircea_Bogdan_Voda` (`RoIMOL_countries_l_russian.yml`).

**Почему так:** единственные подтверждённые документально имена ванильных generic-спрайтов — `GFX_Portrait_Europe_Generic_land_1` и `GFX_Portrait_Europe_Generic_navy_1` (они приведены на вики в примере пула `common/portraits/*.txt` для косметических тегов). Полного списка гражданских generic-спрайтов в открытых источниках нет, а угадывать имя = риск остаться без портрета.

## Как сделать детерминированно (когда понадобятся конкретные лица)
Шаг 1. Взять точные имена/пути из **своей** копии игры:
- `common/portraits/*.txt` — пулы спрайтов (`male = { "GFX_..." }`, `political = { despotism = { male = { ... } } }`);
- `interface/*.gfx` — объявления `spriteType` с `texturefile`;
- подсказка из ванильного закомментированного блока в нашем же `common/characters/MOL.txt`: путь вида `gfx/leaders/Africa/Portrait_Africa_Generic_2.dds` → для Европы по той же схеме будет `gfx/leaders/Europe/Portrait_Europe_Generic_N.dds` (**проверить в своей версии игры**).

Шаг 2. Объявить спрайты в `interface/MOL_GFXes.gfx`:
```
	spriteType = {
		name = "GFX_MOL_monarch_bogdanovici"
		texturefile = "gfx/leaders/Europe/Portrait_Europe_Generic_1.dds"
	}
	spriteType = {
		name = "GFX_MOL_monarch_habsburg"
		texturefile = "gfx/leaders/Europe/Portrait_Europe_Generic_2.dds"
	}
	spriteType = {
		name = "GFX_MOL_monarch_romanov"
		texturefile = "gfx/leaders/Europe/Portrait_Europe_Generic_3.dds"
	}
```
Ограничения на имя спрайта: начинается с `GFX_`, одно слово, только ASCII. `texturefile` — слэши вперёд, расширение обязательно.

Шаг 3. Прописать портреты персонажам:
```
	MOL_Mircea_Bogdan_Voda = {
		name = MOL_Mircea_Bogdan_Voda
		gender = male
		portraits = {
			civilian = {
				large = GFX_MOL_monarch_bogdanovici
			}
		}
	}
```
Альтернатива без спрайтов — путь к текстуре прямо в персонаже (вики это разрешает):
```
		portraits = {
			civilian = {
				large = "gfx/leaders/Europe/Portrait_Europe_Generic_1.dds"
			}
		}
```

Шаг 4. Если портрет всё же «поехал»: удалить блок `portraits` у персонажа → вернётся автогенерация ванильного портрета.

## Замечание про наши .png
В `interface/MOL_GFXes.gfx` три портрета объявлены как `.png` (`gfx/leaders/MOL_LGOV.png`, `grigore_cazacliu.png`, `ion_inculet.png`). Штатный формат HOI4 для `texturefile` — DDS (для флагов — TGA). Если в игре вместо `GFX_MOL_LGOV` подставляется случайный портрет — причина здесь, лечится конвертацией в DDS и правкой `texturefile`.
