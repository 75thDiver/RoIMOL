# -*- coding: utf-8 -*-
"""Аудит common/decisions/*: структура (категория -> решение), дубли, локализация,
иконки, запрещённые идеи, dynamic_modifier'ы, события, флаги/переменные, опечатки токенов."""
import os, re, json, glob, collections, difflib

SKILL = os.path.join("_devtools", "hoi4-modding-skills", "docs")
EFFECTS = {x["name"] for x in json.load(open(os.path.join(SKILL, "01_effects", "effects.json"), encoding="utf-8"))}
TRIGGERS = {x["name"] for x in json.load(open(os.path.join(SKILL, "04_triggers", "triggers.json"), encoding="utf-8"))}
KNOWN = EFFECTS | TRIGGERS

BAD_ICONS = {"GFX_goal_generic_neutrality", "GFX_focus_generic_agrarian_reform",
             "GFX_focus_generic_diplomatic_mission", "GFX_focus_generic_infrastructure_2",
             "GFX_focus_generic_declare_war", "GFX_focus_generic_standing_army"}

# служебные/структурные токены решений и блочные ключи
DECOR = {
    "icon", "allowed", "available", "visible", "activation", "selectable_mission", "is_good",
    "days_mission_timeout", "days", "days_remove", "cost", "fire_only_once", "complete_effect",
    "remove_effect", "timeout_effect", "cancel_effect", "cancel_trigger", "ai_will_do",
    "target_root_trigger", "target_trigger", "targeted_root_trigger", "on_map_mode",
    "highlight_states", "highlight_color_before_active", "highlight_color_while_active",
    "priority", "custom_trigger_tooltip", "custom_effect_tooltip", "custom_cost",
    "state_targeted", "ai_will_do_factor", "modifier", "factor", "base", "days_re_enable",
    "name", "desc", "picture", "major", "show_major", "trigger", "limit", "and", "or", "not",
}
BLOCKY = {
    "if", "else_if", "else", "while", "hidden_effect", "custom_effect_tooltip", "tooltip",
    "random", "log", "every_country", "any_country", "all_country", "random_country",
    "every_other_country", "any_other_country", "every_state", "any_state", "all_state",
    "random_state", "every_controlled_state", "any_controlled_state", "all_controlled_state",
    "random_controlled_state", "every_owned_state", "any_owned_state", "all_owned_state",
    "every_neighbor_country", "any_neighbor_country", "all_neighbor_country",
    "every_character", "any_character", "random_list", "add_to_array", "find_highest_in_array",
    "for_each_loop", "while_loop_effect", "set_temp_variable", "check_variable",
}
issues, notes = [], []


def readb(p):
    raw = open(p, "rb").read()
    try:
        raw.decode("utf-8"); ok = True
    except Exception:
        ok = False
    return ok, raw


def strip_comments(t):
    out = []
    for line in t.split("\n"):
        # убираем комментарий, но не трогаем '#' внутри кавычек
        res, inq = [], False
        for ch in line:
            if ch == '"':
                inq = not inq
            if ch == '#' and not inq:
                break
            res.append(ch)
        out.append("".join(res))
    return "\n".join(out)


# ---------- сбор локализации ----------
loc_keys = set()
for lp in glob.glob("localisation/russian/*.yml"):
    for m in re.finditer(r"^\s*([A-Za-z0-9_.]+)(?::\d*)?\s*:", open(lp, encoding="utf-8-sig").read(), re.M):
        loc_keys.add(m.group(1))

# ---------- события в проекте ----------
ev_ids = set()
for ep in glob.glob("events/*.txt"):
    t = strip_comments(open(ep, encoding="utf-8-sig").read())
    for m in re.finditer(r"^\s*id\s*=\s*([A-Za-z0-9_.]+)", t, re.M):
        ev_ids.add(m.group(1))

categories = collections.defaultdict(list)   # cat -> [file,...]
decisions = {}                               # id -> (file, cat)
icons = collections.Counter()
dyn_add, dyn_rm, dyn_has = collections.Counter(), collections.Counter(), collections.Counter()
forbidden = []
events_used = collections.Counter()
flags_set, flags_has, flags_clr = collections.Counter(), collections.Counter(), collections.Counter()
gflags_set, gflags_has, gflags_clr = collections.Counter(), collections.Counter(), collections.Counter()
variables = collections.Counter()
unknown_tokens = collections.Counter()
missions = {}
custom_tips = collections.Counter()

print("=== ФАЙЛЫ common/decisions ===")
for p in sorted(glob.glob("common/decisions/*.txt")):
    ok, raw = readb(p)
    t = raw.decode("utf-8-sig")
    clean = strip_comments(t)
    o, c = clean.count("{"), clean.count("}")
    bom = raw.startswith(b"\xef\xbb\xbf")
    crlf = b"\r\n" in raw
    eof = raw.endswith(b"\n")
    print("  %-46s braces %4d/%-4d %-4s BOM=%-5s CRLF=%-5s UTF8=%-5s eof_nl=%s"
          % (os.path.basename(p), o, c, "OK" if o == c else "!!!", bom, crlf, ok, eof))
    if o != c:
        issues.append("%s: дисбаланс скобок %d/%d" % (p, o, c))
    if not ok:
        issues.append("%s: не UTF-8" % p)
    if not bom:
        notes.append("%s: нет BOM" % p)

    # --- структурный обход с глубиной ---
    depth = 0
    cur_cat = None
    cur_dec = None
    for ln, line in enumerate(clean.split("\n"), start=1):
        for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\{)?", line):
            tok, brace = m.group(1), m.group(2)
            if depth == 0 and brace:
                cur_cat = tok
                categories[tok].append("%s:%d" % (os.path.basename(p), ln))
            elif depth == 1 and brace:
                cur_dec = tok
                if cur_cat is None:
                    issues.append("%s:%d: решение %s вне блока категории" % (p, ln, tok))
                if tok in decisions:
                    issues.append("ДУБЛЬ id решения: %s (%s и %s)" % (tok, decisions[tok][0], p))
                decisions[tok] = (p, cur_cat, ln)
            # иконка
            if tok == "icon":
                v = re.search(r"icon\s*=\s*([A-Za-z0-9_]+)", line)
                if v:
                    icons[v.group(1)] += 1
            if tok in ("custom_trigger_tooltip", "custom_effect_tooltip"):
                v = re.search(r"(?:custom_trigger_tooltip|custom_effect_tooltip)\s*=\s*([A-Za-z0-9_]+)", line)
                if v:
                    custom_tips[v.group(1)] += 1
            if tok in ("set_country_flag",):
                v = re.search(r"set_country_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: flags_set[v.group(1)] += 1
            if tok in ("has_country_flag",):
                v = re.search(r"has_country_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: flags_has[v.group(1)] += 1
            if tok in ("clr_country_flag",):
                v = re.search(r"clr_country_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: flags_clr[v.group(1)] += 1
            if tok == "set_global_flag":
                v = re.search(r"set_global_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: gflags_set[v.group(1)] += 1
            if tok == "has_global_flag":
                v = re.search(r"has_global_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: gflags_has[v.group(1)] += 1
            if tok == "clr_global_flag":
                v = re.search(r"clr_global_flag\s*=\s*([A-Za-z0-9_]+)", line)
                if v: gflags_clr[v.group(1)] += 1
            if tok in ("set_variable", "add_to_variable", "subtract_from_variable", "set_temp_variable",
                       "multiply_variable", "divide_variable", "check_variable", "clamp_variable"):
                v = re.search(r"%s\s*=\s*\{\s*(?:var|value)?\s*=?\s*([A-Za-z_][A-Za-z0-9_.@]*)" % tok, line)
                if v: variables[v.group(1)] += 1
            if tok == "add_dynamic_modifier":
                v = re.search(r"modifier\s*=\s*([A-Za-z0-9_]+)", line)
                if v: dyn_add[v.group(1)] += 1
            if tok == "remove_dynamic_modifier":
                v = re.search(r"modifier\s*=\s*([A-Za-z0-9_]+)", line)
                if v: dyn_rm[v.group(1)] += 1
            if tok == "has_dynamic_modifier":
                v = re.search(r"modifier\s*=\s*([A-Za-z0-9_]+)", line)
                if v: dyn_has[v.group(1)] += 1
            if tok in ("add_ideas", "has_idea", "remove_ideas", "add_timed_idea"):
                forbidden.append("%s:%d: %s" % (p, ln, tok))
            if tok in ("country_event", "news_event", "state_event", "unit_leader_event", "fire_event"):
                v = re.search(r"id\s*=\s*([A-Za-z0-9_.]+)", line)
                if v: events_used[v.group(1)] += 1
            if tok not in DECOR and tok not in BLOCKY and tok not in KNOWN \
               and re.match(r"^[a-z]", tok) and not re.match(r"^(x|y|var|value|days|hours|id|ratio|tag|factor|base|modifier|scope|limit|trigger|name|desc|icon|cost|priority)$", tok):
                unknown_tokens[tok] += 1
        depth += line.count("{") - line.count("}")
        if depth == 1:
            cur_dec = None
        if depth == 0:
            cur_cat = None
    # --- свойства миссий ---
    for m in re.finditer(r"^\t([A-Za-z0-9_]+)\s*=\s*\{(.*?)^\t\}", clean, re.S | re.M):
        did, body = m.group(1), m.group(2)
        props = {
            "days_mission_timeout": re.search(r"days_mission_timeout\s*=\s*(\d+)", body),
            "activation": "activation" in body,
            "cancel_trigger": "cancel_trigger" in body,
            "cancel_effect": "cancel_effect" in body,
            "timeout_effect": "timeout_effect" in body,
            "complete_effect": "complete_effect" in body,
            "remove_effect": "remove_effect" in body,
            "is_good": re.search(r"is_good\s*=\s*(\w+)", body),
            "fire_only_once": "fire_only_once" in body,
            "selectable_mission": re.search(r"selectable_mission\s*=\s*(\w+)", body),
            "cost": re.search(r"\bcost\s*=\s*([-\d.]+)", body),
            "days": re.search(r"^\s*days\s*=\s*(\d+)", body, re.M),
            "days_remove": re.search(r"days_remove\s*=\s*(\d+)", body),
            "allowed": "allowed" in body,
            "available": "available" in body,
            "visible": "visible" in body,
            "target_trigger": "target_trigger" in body,
            "ai_will_do": "ai_will_do" in body,
        }
        missions[did] = props

print("\n=== КАТЕГОРИИ (блоки верхнего уровня) ===")
for cat, where in sorted(categories.items()):
    loc1 = "OK" if cat in loc_keys else "НЕТ"
    loc2 = "OK" if cat + "_desc" in loc_keys else "НЕТ"
    print("  %-46s определена в: %s   loc(%s/%s_desc=%s)" % (cat, ", ".join(where), loc1, cat, loc2))
    if loc1 == "НЕТ": issues.append("категория %s без ключа локализации" % cat)
    if loc2 == "НЕТ": issues.append("категория %s без %s_desc" % (cat, cat))
    if len(where) > 1: issues.append("категория %s объявлена в нескольких местах: %s" % (cat, where))

print("\n=== РЕШЕНИЯ: %d шт ===" % len(decisions))
by_cat = collections.defaultdict(list)
for did, (f, cat, ln) in decisions.items():
    by_cat[cat].append(did)
for cat in sorted(by_cat, key=lambda x: (x is None, x)):
    print("  [%s] %d шт:" % (cat, len(by_cat[cat])))
    for did in sorted(by_cat[cat]):
        pr = missions.get(did, {})
        tags = []
        if pr.get("days_mission_timeout"): tags.append("mission %sд" % pr["days_mission_timeout"].group(1))
        if pr.get("days"): tags.append("days=%s" % pr["days"].group(1))
        if pr.get("days_remove"): tags.append("days_remove=%s" % pr["days_remove"].group(1))
        if pr.get("cost"): tags.append("cost=%s" % pr["cost"].group(1))
        for k in ("cancel_trigger", "cancel_effect", "timeout_effect", "complete_effect", "remove_effect",
                  "activation", "allowed", "available", "visible", "target_trigger", "ai_will_do", "fire_only_once"):
            if pr.get(k) in (True,): tags.append(k)
        loc1 = "" if did in loc_keys else " [БЕЗ LOC]"
        loc2 = "" if did + "_desc" in loc_keys else " [БЕЗ _desc]"
        print("     %-46s %-52s%s%s" % (did, ", ".join(tags), loc1, loc2))
        if loc1: issues.append("решение %s без ключа локализации" % did)
        if loc2: issues.append("решение %s без %s_desc" % (did, did))

print("\n=== МИССИИ *_thirty_days_of_fire ===")
for did, pr in sorted(missions.items()):
    if "thirty_days" in did:
        d = pr["days_mission_timeout"].group(1) if pr.get("days_mission_timeout") else "НЕТ"
        print("  %-34s timeout=%s activation=%s cancel_trigger=%s cancel_effect=%s timeout_effect=%s is_good=%s"
              % (did, d, pr.get("activation"), pr.get("cancel_trigger"), pr.get("cancel_effect"),
                 pr.get("timeout_effect"), pr["is_good"].group(1) if pr.get("is_good") else "-"))
        if d != "30": issues.append("%s: days_mission_timeout=%s (ожидалось 30)" % (did, d))
        for k in ("cancel_trigger", "timeout_effect"):
            if not pr.get(k): issues.append("%s: нет %s" % (did, k))

print("\n=== ИКОНКИ (%d уникальных) ===" % len(icons))
for ic, n in icons.most_common():
    mark = "  <<< ИЗ ЧЁРНОГО СПИСКА" if ic in BAD_ICONS else ""
    print("  %-46s x%d%s" % (ic, n, mark))
    if ic in BAD_ICONS: issues.append("битая ванильная иконка %s (x%d)" % (ic, n))
    if ic.startswith("GFX_"): notes.append("иконка %s — нужно проверить наличие спрайта" % ic)

print("\n=== ЗАПРЕЩЁННОЕ (add_ideas/has_idea) ===")
print("  %s" % (forbidden if forbidden else "не найдено — OK"))
for f in forbidden: issues.append("запрещённый вызов: " + f)

print("\n=== dynamic_modifier'ы ===")
print("  add: %s" % dict(dyn_add))
print("  remove: %s" % dict(dyn_rm))
print("  has: %s" % dict(dyn_has))
for m in set(list(dyn_add) + list(dyn_rm) + list(dyn_has)):
    notes.append("dynamic_modifier %s — сверить с common/dynamic_modifiers/ROIMOL_ideas.txt (ещё не передан)" % m)
unpaired = [m for m in dyn_add if m not in dyn_rm]
print("  add без remove: %s" % (unpaired if unpaired else "-"))

print("\n=== СОБЫТИЯ, вызываемые из решений ===")
for ev, n in sorted(events_used.items()):
    st = "есть в events/" if ev in ev_ids else ("есть ключ loc" if ev + ".t" in loc_keys or ev in loc_keys else "НЕ НАЙДЕНО")
    print("  %-30s x%d  %s" % (ev, n, st))
    if st == "НЕ НАЙДЕНО": issues.append("событие %s вызывается из решений, но не определено" % ev)

print("\n=== ФЛАГИ ===")
print("  set_country_flag: %s" % sorted(flags_set))
print("  has_country_flag: %s" % sorted(flags_has))
print("  clr_country_flag: %s" % sorted(flags_clr))
print("  set_global_flag : %s" % sorted(gflags_set))
print("  has_global_flag : %s" % sorted(gflags_has))
print("  clr_global_flag : %s" % sorted(gflags_clr))
for f in set(flags_has) - set(flags_set):
    notes.append("флаг %s проверяется, но в решениях не выставляется (ищи в фокусах/событиях)" % f)
for f in set(flags_set) - set(flags_has) - set(flags_clr):
    notes.append("флаг %s выставляется, но нигде не проверяется/снимается в решениях" % f)

print("\n=== ПЕРЕМЕННЫЕ ===")
print("  %s" % sorted(variables))

print("\n=== custom_*_tooltip ===")
for k, n in sorted(custom_tips.items()):
    st = "OK" if k in loc_keys else "НЕТ В ЛОКАЛИЗАЦИИ"
    print("  %-40s x%d %s" % (k, n, st))
    if st != "OK": issues.append("custom tooltip %s без локализации" % k)

print("\n=== ПОДОЗРИТЕЛЬНЫЕ ТОКЕНЫ (нет в БД скиллов: %d эффектов + %d триггеров) ===" % (len(EFFECTS), len(TRIGGERS)))
shown = 0
for tok, n in unknown_tokens.most_common():
    close = difflib.get_close_matches(tok, KNOWN, n=1, cutoff=0.82)
    if close:
        print("  [?] %-34s x%-3d возможно опечатка: %s" % (tok, n, close[0]))
        issues.append("подозрительный токен %s (близко к %s) — проверить" % (tok, close[0]))
        shown += 1
rest = [(t, n) for t, n in unknown_tokens.most_common() if not difflib.get_close_matches(t, KNOWN, n=1, cutoff=0.82)]
print("  прочие несовпавшие (%d шт, обычно это валидные токены вне урезанной БД / имена скриптов): %s"
      % (len(rest), ", ".join("%s x%d" % (t, n) for t, n in rest[:40])))

print("\n=== ИТОГ ===")
print("ПРОБЛЕМ: %d" % len(issues))
for x in issues: print("  [P] " + x)
print("ЗАМЕТОК: %d" % len(notes))
for x in notes[:45]: print("  [N] " + x)
if len(notes) > 45: print("  ... ещё %d" % (len(notes) - 45))
