# -*- coding: utf-8 -*-
"""Индекс скиллов hoi4-modding-skills: name/description/триггеры + размеры references."""
import os, re, glob

REPO = os.path.join("_devtools", "hoi4-modding-skills")
SK = os.path.join(REPO, "skills")

rows = []
for sk in sorted(os.listdir(SK)):
    p = os.path.join(SK, sk, "SKILL.md")
    if not os.path.isfile(p):
        continue
    raw = open(p, 'rb').read().decode('utf-8-sig')
    fm = {}
    m = re.match(r'^---\s*\n(.*?)\n---\s*\n', raw, re.S)
    body = raw
    if m:
        body = raw[m.end():]
        for line in m.group(1).split('\n'):
            mm = re.match(r'^([A-Za-z0-9_\-]+)\s*:\s*(.*)$', line)
            if mm:
                fm[mm.group(1)] = mm.group(2).strip()
    refs = []
    for r in sorted(glob.glob(os.path.join(SK, sk, "references", "*"))):
        refs.append("%s (%d КБ)" % (os.path.basename(r), os.path.getsize(r) // 1024))
    for r in sorted(glob.glob(os.path.join(SK, sk, "scripts", "*"))):
        refs.append("script:" + os.path.basename(r))
    for r in sorted(glob.glob(os.path.join(SK, sk, "assets", "**", "*"), recursive=True)):
        if os.path.isfile(r):
            refs.append("asset:" + os.path.relpath(r, os.path.join(SK, sk)))
    heads = [h.strip() for h in re.findall(r'^#{1,3}\s+(.+)$', body, re.M)][:14]
    rows.append((sk, fm.get('name', ''), fm.get('description', ''),
                 os.path.getsize(p), refs, heads, body.count('\n')))

print("=== СКИЛЛЫ: %d шт ===\n" % len(rows))
for sk, name, desc, size, refs, heads, nl in rows:
    print("### %s   [%d строк SKILL.md, %d КБ]" % (sk, nl, size // 1024))
    if name and name != sk:
        print("  name: %s" % name)
    if desc:
        print("  desc: %s" % (desc[:600] + ('...' if len(desc) > 600 else '')))
    if refs:
        print("  refs: %s" % "; ".join(refs))
    print("  разделы: %s" % " | ".join(heads))
    print()
