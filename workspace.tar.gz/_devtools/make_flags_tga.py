# -*- coding: utf-8 -*-
"""Конвертер графики RoIMOL в TGA под требования HOI4.

Гарантии (проверены эмпирически, см. отчёт 2026-09-19):
  * imagetype = 2  -> true-color БЕЗ RLE-сжатия;
  * 32 bpp         -> BGRA с 8-битной альфой;
  * дескриптор бит5 = 0 и первая строка в файле = нижняя -> origin bottom-left;
  * точные пиксельные размеры из пресетов.

Пресеты размеров (вики Paradox, NDefines.NGraphics):
  flag        82x52   gfx/flags/<имя>.tga
  flag_medium 41x26   gfx/flags/medium/<имя>.tga
  flag_small  10x7    gfx/flags/small/<имя>.tga
  portrait    156x210 (портреты лидеров/генералов; в ванили обычно .dds — см. примечание)

Использование:
  python3 _devtools/make_flags_tga.py SRC OUT_ROOT ИМЯ [--mode cover|contain] [--bg R,G,B]
                                      [--sizes flag,flag_medium,flag_small | --all3]
  ИМЯ = базовое имя файла без расширения, например PMR_neutrality или PMR_tsarist_loyalists_neutrality.
  --all3 пишет сразу три размера в правильные подпапки OUT_ROOT/gfx/flags[/medium|/small].

Примечание про DDS: фокус-иконки, иконки идей/решений и портреты в ванили лежат в .dds.
TGA для них игра не ждёт; данный скрипт TGA-ONLY (флаги). Некриптованный DDS я могу собрать
вручную (заголовок + BGRA), но приём uncompressed DDS движком не подтверждён — помечаю как
uncertainty и по умолчанию не делаю.
"""
import argparse, os, struct, sys
from PIL import Image

PRESETS = {
    'flag':        (82, 52,  os.path.join('gfx', 'flags')),
    'flag_medium': (41, 26,  os.path.join('gfx', 'flags', 'medium')),
    'flag_small':  (10, 7,   os.path.join('gfx', 'flags', 'small')),
    'portrait':    (156, 210, os.path.join('gfx', 'leaders')),
}


def fit(src, w, h, mode, bg):
    im = src.convert('RGBA')
    sw, sh = im.size
    if mode == 'stretch':
        # точное приведение к размеру без сохранения пропорций:
        # для флагов это сохраняет композицию (равные трети полос), лишь слегка сжимая по горизонтали
        return im.resize((w, h), Image.LANCZOS)
    if mode == 'cover':
        k = max(w / sw, h / sh)
        nw, nh = max(1, round(sw * k)), max(1, round(sh * k))
        im = im.resize((nw, nh), Image.LANCZOS)
        l = (nw - w) // 2
        t = (nh - h) // 2
        im = im.crop((l, t, l + w, t + h))
    else:  # contain: вписываем и кладём на подложку
        k = min(w / sw, h / sh)
        nw, nh = max(1, round(sw * k)), max(1, round(sh * k))
        im = im.resize((nw, nh), Image.LANCZOS)
        canvas = Image.new('RGBA', (w, h), tuple(bg) + (255,))
        canvas.paste(im, ((w - nw) // 2, (h - nh) // 2), im)
        im = canvas
    return im


def save_tga(im, path):
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    im.save(path, 'TGA')          # rle выключен по умолчанию; orientation -> bottom-left
    verify(path, im.size)


def verify(path, expect_size):
    b = open(path, 'rb').read()
    id_len, cmap, itype = b[0], b[1], b[2]
    w, h = struct.unpack('<HH', b[12:16])
    bpp, desc = b[16], b[17]
    probs = []
    if itype != 2:  probs.append('imagetype=%d (RLE?)' % itype)
    if bpp != 32:   probs.append('bpp=%d (не 32)' % bpp)
    if (desc >> 5) & 1: probs.append('origin сверху (бит5=1)')
    if (desc & 0x0F) != 8: probs.append('альфа не 8 бит')
    if (w, h) != expect_size: probs.append('размер %dx%d != %dx%d' % (w, h, *expect_size))
    want = 18 + id_len + w * h * 4 + 26
    if len(b) != want: probs.append('размер файла %d != %d' % (len(b), want))
    # первая строка пикселей должна быть нижней строкой изображения
    st = Image.open(path); st.load()
    if st.size != expect_size: probs.append('не читается обратно')
    if probs:
        raise SystemExit('  [!] %s: %s' % (path, '; '.join(probs)))
    print('  [OK] %-58s %3dx%-3d 32bit без RLE, bottom-left, %d Б' % (path, w, h, len(b)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('src')
    ap.add_argument('out_root')
    ap.add_argument('name')
    ap.add_argument('--mode', default='cover', choices=['cover', 'contain', 'stretch'])
    ap.add_argument('--bg', default='0,0,0')
    ap.add_argument('--sizes', default='')
    ap.add_argument('--all3', action='store_true')
    a = ap.parse_args()
    bg = [int(x) for x in a.bg.split(',')]
    src = Image.open(a.src)
    sizes = []
    if a.all3:
        sizes = ['flag', 'flag_medium', 'flag_small']
    elif a.sizes:
        sizes = a.sizes.split(',')
    else:
        sizes = ['flag']
    for s in sizes:
        w, h, sub = PRESETS[s]
        out = os.path.join(a.out_root, sub, a.name + '.tga')
        save_tga(fit(src, w, h, a.mode, bg), out)


if __name__ == '__main__':
    main()
