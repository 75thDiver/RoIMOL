# -*- coding: utf-8 -*-
"""ЗЕЛЁНАЯ ВЕТКА: перенос вправо, расширение, развилка династий, чистка аномалий (UKR)."""
import os, re, shutil, datetime

STAMP = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
BK = os.path.join('_devtools', 'backup_mon_' + STAMP)
FILES = ['common/national_focus/moldova.txt', 'common/characters/MOL.txt',
         'common/country_leader/traits.txt', 'common/dynamic_modifiers/ROIMOL_ideas.txt',
         'history/countries/MOL - Moldova.txt']

def read(p): return open(p, encoding='utf-8', newline='').read()
def write(p, s): open(p, 'w', encoding='utf-8', newline='').write(s)

os.makedirs(BK, exist_ok=True)
for p in FILES:
    shutil.copy2(p, os.path.join(BK, p.replace('/', '__')))
print('бэкап ->', BK)

T = '\t'
def F(body):
    """Собирает блок focus = { ... } с табуляциями."""
    out = [T + 'focus = {']
    for line in body.strip('\n').split('\n'):
        out.append((T + T + line) if line else '')
    out.append(T + '}')
    return '\n'.join(out)

# =====================================================================
# НОВОЕ ДЕРЕВО ЗЕЛЁНОЙ ВЕТКИ
# =====================================================================
parts = []
parts.append(T + '# ==================== ЗЕЛЁНАЯ ВЕТКА (Монархисты) ====================')

parts.append(F('''id = MOL_mon_government
icon = GFX_focus_generic_monarchy_1
prerequisite = { focus = MOL_victory }
x = 38
y = 1
relative_position_id = MOL_victory
cost = 5
search_filters = { FOCUS_FILTER_POLITICAL }
available = { always = no }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tset_country_flag = MOL_mon_path
}'''))

parts.append(F('''id = MOL_mon_restoration
icon = GFX_focus_generic_monarchy_2
prerequisite = { focus = MOL_mon_government }
x = 0
y = 1
relative_position_id = MOL_mon_government
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_political_power = 75
\tset_cosmetic_tag = Free_MOL
\tset_party_name = {
\t\tideology = neutrality
\t\tlong_name = MOL_monarchist_party_long
\t\tname = MOL_monarchist_party
\t}
}'''))

parts.append(T + '\t# --- Съезд претендентов: кого позовём на трон ---')
parts.append(F('''id = MOL_mon_crown
icon = GFX_focus_generic_congress
prerequisite = { focus = MOL_mon_restoration }
x = 0
y = 1
relative_position_id = MOL_mon_restoration
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 100
\tadd_popularity = { ideology = neutrality popularity = 0.15 }
\tset_country_flag = MOL_crown_found
\tcustom_effect_tooltip = MOL_mon_dynasty_choice_tt
}'''))

# ---------- Развилка династий ----------
parts.append(T + '\t# === РАЗВИЛКА ДИНАСТИЙ (взаимоисключающие) ===')

parts.append(F('''id = MOL_mon_dynasty_native
icon = GFX_focus_generic_monarchy_2
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_habsburg }
mutually_exclusive = { focus = MOL_mon_dynasty_romanov }
x = -6
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_native
\tadd_stability = 0.08
\tadd_political_power = 50
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
\tcustom_effect_tooltip = MOL_mon_dynasty_native_tt
}'''))

parts.append(F('''id = MOL_mon_dynasty_habsburg
icon = GFX_focus_generic_treaty
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_native }
mutually_exclusive = { focus = MOL_mon_dynasty_romanov }
x = 0
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_habsburg
\tadd_political_power = 75
\tadd_stability = -0.03
\tevery_other_country = {
\t\tlimit = {
\t\t\tOR = {
\t\t\t\toriginal_tag = AUS
\t\t\t\toriginal_tag = HUN
\t\t\t\toriginal_tag = ROM
\t\t\t\toriginal_tag = ITA
\t\t\t}
\t\t\thas_government = neutrality
\t\t}
\t\tadd_opinion_modifier = { target = ROOT modifier = MOL_trade_agreement }
\t}
\tcustom_effect_tooltip = MOL_mon_dynasty_habsburg_tt
}'''))

parts.append(F('''id = MOL_mon_dynasty_romanov
icon = GFX_focus_generic_monarchy_1
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_native }
mutually_exclusive = { focus = MOL_mon_dynasty_habsburg }
x = 6
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_romanov
\tadd_war_support = 0.10
\tadd_stability = -0.05
\tadd_manpower = 15000
\tSOV = {
\t\tadd_opinion_modifier = { target = ROOT modifier = MOL_subversive_diplomacy }
\t}
\tcustom_effect_tooltip = MOL_mon_dynasty_romanov_tt
}'''))

# ---------- Коронация ----------
parts.append(F('''id = MOL_mon_coronation
icon = GFX_focus_rom_royal_dictatorship
prerequisite = { focus = MOL_mon_dynasty_native focus = MOL_mon_dynasty_habsburg focus = MOL_mon_dynasty_romanov }
x = 0
y = 2
relative_position_id = MOL_mon_crown
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.15
\tadd_war_support = 0.10
\tadd_dynamic_modifier = { modifier = MOL_princely_rule }
\tif = {
\t\tlimit = { has_country_flag = MOL_dynasty_native }
\t\tset_party_name = {
\t\t\tideology = neutrality
\t\t\tlong_name = MOL_bogdanovici_party_long
\t\t\tname = MOL_bogdanovici_party
\t\t}
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Mircea_Bogdan_Voda
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = {
\t\t\t\tideology = despotism
\t\t\t\texpire = "1970.1.1.1"
\t\t\t\ttraits = { bogdanovici_dynasty }
\t\t\t}
\t\t}
\t}
\telse_if = {
\t\tlimit = { has_country_flag = MOL_dynasty_habsburg }
\t\tset_party_name = {
\t\t\tideology = neutrality
\t\t\tlong_name = MOL_habsburg_party_long
\t\t\tname = MOL_habsburg_party
\t\t}
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Leopold_Karl_Habsburg
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = {
\t\t\t\tideology = despotism
\t\t\t\texpire = "1970.1.1.1"
\t\t\t\ttraits = { habsburg_diplomat }
\t\t\t}
\t\t}
\t}
\telse_if = {
\t\tlimit = { has_country_flag = MOL_dynasty_romanov }
\t\tset_party_name = {
\t\t\tideology = neutrality
\t\t\tlong_name = MOL_romanov_party_long
\t\t\tname = MOL_romanov_party
\t\t}
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Tsar_Alexiy_III
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = {
\t\t\t\tideology = despotism
\t\t\t\texpire = "1970.1.1.1"
\t\t\t\ttraits = { romanov_imperial }
\t\t\t}
\t\t}
\t}
\telse = {
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Prince
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = {
\t\t\t\tideology = despotism
\t\t\t\texpire = "1965.1.1.1"
\t\t\t\ttraits = { prince_of_moldavia }
\t\t\t}
\t\t}
\t}
}'''))

# ---------- Линия своей династии ----------
parts.append(T + '\t# === ЛИНИЯ СВОЕЙ ДИНАСТИИ: господарь и народ ===')
parts.append(F('''id = MOL_mon_native_sfatul
icon = GFX_focus_generic_improve_the_administration
prerequisite = { focus = MOL_mon_coronation }
x = -6
y = 1
relative_position_id = MOL_mon_coronation
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available = { has_country_flag = MOL_dynasty_native }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_native_dynasty_spirit }
}'''))

parts.append(F('''id = MOL_mon_native_land_army
icon = GFX_focus_generic_manpower
prerequisite = { focus = MOL_mon_native_sfatul }
x = 0
y = 1
relative_position_id = MOL_mon_native_sfatul
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available = { has_country_flag = MOL_dynasty_native }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 15000
\tadd_stability = 0.05
\tarmy_experience = 50
\tadd_dynamic_modifier = { modifier = MOL_militia_reserves }
}'''))

# ---------- Линия Габсбургов ----------
parts.append(T + '\t# === ЛИНИЯ ГАБСБУРГОВ: двор, торговля и Дунайский пакт ===')
parts.append(F('''id = MOL_mon_habsburg_diplomacy
icon = GFX_goal_generic_improve_relations
prerequisite = { focus = MOL_mon_coronation }
x = 0
y = 1
relative_position_id = MOL_mon_coronation
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_RESEARCH }
available = { has_country_flag = MOL_dynasty_habsburg }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_habsburg_court }
}'''))

parts.append(F('''id = MOL_mon_danubian_pact
icon = GFX_goal_generic_major_alliance
prerequisite = { focus = MOL_mon_habsburg_diplomacy }
x = 0
y = 1
relative_position_id = MOL_mon_habsburg_diplomacy
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tNOT = { has_war_with = ROM }
}
available_if_capitulated = yes
bypass = { is_faction_leader = yes }
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tif = {
\t\tlimit = { is_in_faction = no }
\t\tcreate_faction = MOL_danubian_pact
\t}
\tif = {
\t\tlimit = { is_faction_leader = yes }
\t\tevery_other_country = {
\t\t\tlimit = {
\t\t\t\tOR = {
\t\t\t\t\toriginal_tag = AUS
\t\t\t\t\toriginal_tag = HUN
\t\t\t\t\toriginal_tag = ROM
\t\t\t\t\toriginal_tag = BUL
\t\t\t\t\toriginal_tag = GRE
\t\t\t\t\toriginal_tag = YUG
\t\t\t\t\toriginal_tag = ALB
\t\t\t\t}
\t\t\t\tis_subject = no
\t\t\t\tis_in_faction = no
\t\t\t\tNOT = { has_government = communism }
\t\t\t\tNOT = { has_war_with = ROOT }
\t\t\t}
\t\t\tcountry_event = { id = generic.5 days = 1 }
\t\t}
\t}
\tcustom_effect_tooltip = MOL_mon_danubian_pact_tt
}'''))

# ---------- Линия Романовых ----------
parts.append(T + '\t# === ЛИНИЯ РОМАНОВЫХ: двор в изгнании и путь на юг ===')
parts.append(F('''id = MOL_mon_romanov_emigre
icon = GFX_goal_generic_allies_build_infantry
prerequisite = { focus = MOL_mon_coronation }
x = 6
y = 1
relative_position_id = MOL_mon_coronation
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 25000
\tadd_war_support = 0.05
\tarmy_experience = 50
\tadd_dynamic_modifier = { modifier = MOL_romanov_court }
}'''))

parts.append(F('''id = MOL_mon_romanov_south
icon = GFX_focus_attack_soviet
prerequisite = { focus = MOL_mon_romanov_emigre }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_emigre
cost = 15
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tSOV = { exists = yes }
\tNOT = { has_war_with = SOV }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tSOV = { exists = no }
\t\towns_state = 192
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_state_claim = 192
\tadd_state_claim = 196
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = SOV
\t\tgenerator = { 192 196 }
\t}
}'''))

# ---------- Общая развилка после династий ----------
parts.append(T + '\t# --- Развилка: Культурное возрождение или Экспансия ---')
parts.append(F('''id = MOL_mon_orthodox_state
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_native_land_army focus = MOL_mon_danubian_pact focus = MOL_mon_romanov_south }
mutually_exclusive = { focus = MOL_mon_historical_claims }
x = -3
y = 4
relative_position_id = MOL_mon_coronation
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_orthodox_state }
}'''))

parts.append(F('''id = MOL_mon_historical_claims
icon = GFX_goal_generic_demand_territory
prerequisite = { focus = MOL_mon_native_land_army focus = MOL_mon_danubian_pact focus = MOL_mon_romanov_south }
mutually_exclusive = { focus = MOL_mon_orthodox_state }
x = 3
y = 4
relative_position_id = MOL_mon_coronation
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_war_support = 0.15
\tadd_manpower = 20000
\tset_country_flag = MOL_historical_expansion
}'''))

parts.append(T + '\t# === КУЛЬТУРНАЯ ВЕТКА ===')
parts.append(F('''id = MOL_mon_nobility
icon = GFX_focus_generic_improve_the_administration
prerequisite = { focus = MOL_mon_orthodox_state }
x = 0
y = 1
relative_position_id = MOL_mon_orthodox_state
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_restored_nobility }
}'''))

parts.append(F('''id = MOL_mon_cultural_revival
icon = GFX_goal_generic_propaganda
prerequisite = { focus = MOL_mon_nobility }
x = 0
y = 1
relative_position_id = MOL_mon_nobility
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_war_support = 0.05
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
}'''))

parts.append(F('''id = MOL_mon_peaceful_expansion
icon = GFX_goal_generic_improve_relations
prerequisite = { focus = MOL_mon_cultural_revival }
x = 0
y = 1
relative_position_id = MOL_mon_cultural_revival
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 100
\tif = {
\t\tlimit = { ROM = { is_in_faction = no } }
\t\tcreate_wargoal = { type = puppet_wargoal_goal target = ROM }
\t}
}'''))

parts.append(T + '\t# === ЭКСПАНСИОНИСТСКАЯ ВЕТКА ===')
parts.append(F('''id = MOL_mon_army
icon = GFX_goal_generic_army_doctrines
prerequisite = { focus = MOL_mon_historical_claims }
x = 0
y = 1
relative_position_id = MOL_mon_historical_claims
cost = 15
search_filters = { FOCUS_FILTER_RESEARCH }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 75
\tadd_doctrine_cost_reduction = {
\t\tname = land_doc_bonus
\t\tcost_reduction = 0.5
\t\tuses = 2
\t\tcategory = land_doctrine
\t}
\tadd_manpower = 25000
}'''))

parts.append(F('''id = MOL_mon_conquest
icon = GFX_goal_generic_major_war
prerequisite = { focus = MOL_mon_army }
x = 0
y = 1
relative_position_id = MOL_mon_army
cost = 10
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tROM = { exists = yes }
\tNOT = { has_war_with = ROM }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tROM = { exists = no }
\t\towns_state = 79
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_state_claim = 79
\tadd_state_claim = 80
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = ROM
\t\tgenerator = { 79 80 }
\t}
}'''))

parts.append(F('''id = MOL_mon_grand_moldavia
icon = GFX_goal_generic_military_sphere
prerequisite = { focus = MOL_mon_conquest }
x = 0
y = 1
relative_position_id = MOL_mon_conquest
cost = 25
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_ANNEXATION }
available_if_capitulated = yes
bypass = {
\tOR = {
\t\towns_state = 79
\t\towns_state = 80
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_stability = 0.10
\tadd_manpower = 50000
\t78 = { add_core_of = ROOT }
\t766 = { add_core_of = ROOT }
\t79 = { add_core_of = ROOT }
\t80 = { add_core_of = ROOT }
\tadd_dynamic_modifier = { modifier = MOL_grand_moldavia }
}'''))

NEW_BRANCH = '\n'.join(parts)

# =====================================================================
# 1. подменяем ветку в дереве
# =====================================================================
p = 'common/national_focus/moldova.txt'
s = read(p)
marker = T + '# ==================== ЗЕЛЁНАЯ ВЕТКА (Монархисты) ===================='
i = s.index(marker)
j = s.index(T + T + 'id = MOL_mon_grand_moldavia')
st = s.rindex(T + 'focus = {', 0, j)
d = 0; k = s.index('{', st)
while True:
    if s[k] == '{': d += 1
    elif s[k] == '}':
        d -= 1
        if d == 0:
            end = k + 1
            break
    k += 1
old_len = end - i
s = s[:i] + NEW_BRANCH + s[end:]
write(p, s)
print('[OK] moldova.txt: ветка заменена (было %d байт, стало %d), x-якорь 25 -> 38' % (old_len, len(NEW_BRANCH)))

# =====================================================================
# 2. персонажи
# =====================================================================
p = 'common/characters/MOL.txt'
s = read(p)
NEW_CHARS = '''
\t# === Монархи трёх династий (вымышленные; портреты генерируются игрой из ванильного пула) ===
\tMOL_Mircea_Bogdan_Voda = {
\t\tname = MOL_Mircea_Bogdan_Voda
\t\tgender = male
\t}
\tMOL_Leopold_Karl_Habsburg = {
\t\tname = MOL_Leopold_Karl_Habsburg
\t\tgender = male
\t}
\tMOL_Tsar_Alexiy_III = {
\t\tname = MOL_Tsar_Alexiy_III
\t\tgender = male
\t}
'''
if 'MOL_Mircea_Bogdan_Voda' not in s:
    last = s.rstrip().rindex('}')      # закрывающая скобка characters = {
    s = s.rstrip()[:last] + NEW_CHARS + '}\n'
    write(p, s)
    print('[OK] characters/MOL.txt: +3 персонажа')
else:
    print('[--] characters/MOL.txt: уже есть')

# =====================================================================
# 3. recruit_character (персонаж без рекрутинга не появляется в игре!)
# =====================================================================
p = 'history/countries/MOL - Moldova.txt'
s = read(p)
anchor = 'recruit_character = ROM_MOL_Ion_Inculet\r\n'
NEW_REC = ('recruit_character = MOL_Mircea_Bogdan_Voda\r\n'
           'recruit_character = MOL_Leopold_Karl_Habsburg\r\n'
           'recruit_character = MOL_Tsar_Alexiy_III\r\n'
           'recruit_character = MOL_Prince\r\n'
           'recruit_character = MOL_Red_Leader\r\n'
           'recruit_character = MOL_President\r\n')
if 'MOL_Mircea_Bogdan_Voda' not in s:
    assert anchor in s, 'не найден якорь recruit_character'
    s = s.replace(anchor, anchor + NEW_REC, 1)
    write(p, s)
    print('[OK] history/countries: +6 recruit_character (3 монарха + 3 прежних лидера веток)')
else:
    print('[--] history/countries: уже есть')

# =====================================================================
# 4. трейты лидеров
# =====================================================================
p = 'common/country_leader/traits.txt'
s = read(p)
NEW_TRAITS = '''
# === Династии (зелёная ветка) ===
bogdanovici_dynasty = {
\trandom = no
\tstability_factor = 0.08
\twar_support_factor = 0.05
\tconscription = 0.01
\tdrift_defence_factor = 0.5
\tresearch_speed_factor = -0.05
}

habsburg_diplomat = {
\trandom = no
\ttrade_opinion_factor = 0.25
\tresearch_speed_factor = 0.05
\timprove_relations_maintain_cost_factor = -0.25
\tpolitical_power_factor = 0.10
\tconscription_factor = -0.10
\twar_support_factor = -0.05
}

romanov_imperial = {
\trandom = no
\tarmy_org_factor = 0.05
\ttraining_time_factor = -0.10
\tconscription_factor = 0.10
\tsurrender_limit = 0.10
\tjustify_war_goal_time = -0.10
\tstability_factor = -0.08
\tconsumer_goods_factor = 0.05
}
'''
if 'bogdanovici_dynasty' not in s:
    if not s.endswith('\n'):
        s += '\n'
    s += NEW_TRAITS
    write(p, s)
    print('[OK] country_leader/traits.txt: +3 трейта')
else:
    print('[--] traits: уже есть')

# =====================================================================
# 5. динамические модификаторы династий
# =====================================================================
p = 'common/dynamic_modifiers/ROIMOL_ideas.txt'
s = read(p)
NEW_DM = '''
# === Нацдухи династий (зелёная ветка) ===
MOL_native_dynasty_spirit = {
\ticon = "GFX_idea_generic_national_unity"
\tenable = { always = yes }
\tstability_factor = 0.05
\tconscription = 0.015
\tarmy_core_defence_factor = 0.10
\tpolitical_power_gain = 0.10
\tmin_export = -0.05
}

MOL_habsburg_court = {
\ticon = "GFX_idea_generic_trade"
\tenable = { always = yes }
\tresearch_speed_factor = 0.05
\ttrade_opinion_factor = 0.20
\tproduction_speed_buildings_factor = 0.05
\timprove_relations_maintain_cost_factor = -0.20
\tconsumer_goods_factor = -0.03
\tpolitical_power_gain = 0.15
}

MOL_romanov_court = {
\ticon = "GFX_idea_generic_army_war_college"
\tenable = { always = yes }
\tarmy_org_factor = 0.05
\ttraining_time_factor = -0.10
\tconscription_factor = 0.10
\tsurrender_limit = 0.10
\twar_support_factor = 0.05
\tjustify_war_goal_time = -0.10
\tconsumer_goods_factor = 0.05
}
'''
if 'MOL_native_dynasty_spirit' not in s:
    if not s.endswith('\n'):
        s += '\n'
    s += NEW_DM
    write(p, s)
    print('[OK] dynamic_modifiers: +3 нацдуха династий')
else:
    print('[--] dynamic_modifiers: уже есть')
