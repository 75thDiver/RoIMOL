# -*- coding: utf-8 -*-
"""Быстрый аудит целостности локализации и событий RoIMOL (без анализа содержания)."""
import os, re, collections

ROOT = os.getcwd()          # запускать из корня проекта
LOC = os.path.join(ROOT, "localisation", "russian")
EV = os.path.join(ROOT, "events")

problems, warnings = [], []
accepted = []
keys_global = collections.defaultdict(list)

# --- реестр осознанно принятых владельцем решений ---
ACC_SIGS = []
_acc_path = os.path.join('_devtools', 'accepted_issues.json')
if os.path.isfile(_acc_path):
    import json as _json
    _acc = _json.load(open(_acc_path, encoding='utf-8'))
    for _grp in ('loc', 'script_files'):
        for _it in _acc.get(_grp, []):
            ACC_SIGS.append((_it.get('signature') or _it.get('id'), _it['decision']))


def is_accepted(msg):
    for sig, dec in ACC_SIGS:
        if sig and sig in msg:
            return dec
    return False


def read(path):
    raw = open(path, 'rb').read()
    try:
        raw.decode('utf-8')
        ok = True
    except Exception:
        ok = False
    return ok, raw


print("=== ЛОКАЛИЗАЦИЯ ===")
for fn in sorted(os.listdir(LOC)):
    p = os.path.join(LOC, fn)
    ok, raw = read(p)
    bom = raw.startswith(b'\xef\xbb\xbf')
    text = raw.decode('utf-8-sig')
    lines = text.split('\n')
    nkeys = 0
    if not ok:
        problems.append("%s: НЕ валидный UTF-8" % fn)
    if not bom:
        warnings.append("%s: нет UTF-8 BOM (HOI4 требует BOM для кириллицы)" % fn)
    if lines[0].strip() != 'l_russian:':
        problems.append("%s: первая строка не 'l_russian:' -> %r" % (fn, lines[0]))
    for i, l in enumerate(lines[1:], start=2):
        if not l.strip() or l.strip().startswith('#'):
            continue
        m = re.match(r'^\s*([A-Za-z0-9_.\-]+):(\d*)\s*(.*)$', l)
        if not m:
            problems.append("%s:%d: непарсимая строка: %r" % (fn, i, l[:70]))
            continue
        key, ver, val = m.group(1), m.group(2), m.group(3)
        nkeys += 1
        keys_global[key].append("%s:%d" % (fn, i))
        if val == '':
            problems.append("%s:%d: пустое значение у ключа %s" % (fn, i, key))
            continue
        if val.startswith('"'):
            body = val[1:]
            mm = re.match(r'^((?:[^"\\]|\\.)*)"\s*$', body)
            if not mm:
                problems.append("%s:%d: %s: подозрительные кавычки -> %r" % (fn, i, key, val[:80]))
            elif '"' in mm.group(1):
                problems.append("%s:%d: %s: внутренние кавычки не экранированы" % (fn, i, key))
        else:
            warnings.append("%s:%d: %s: значение БЕЗ кавычек -> %r" % (fn, i, key, val[:40]))
    print("  %-42s ключей: %4d  BOM: %-3s строк: %d" % (fn, nkeys, 'да' if bom else 'НЕТ', len(lines)))

print("\n=== ДУБЛИ КЛЮЧЕЙ ===")
dups = {k: v for k, v in keys_global.items() if len(v) > 1}
if not dups:
    print("  нет")
for k, v in sorted(dups.items()):
    same = len(set(x.split(':')[0] for x in v)) == 1
    tag = "внутри одного файла" if same else "МЕЖДУ файлами"
    print("  %-55s x%d (%s) -> %s" % (k, len(v), tag, ', '.join(v)))
print("  всего уникальных ключей: %d, дублей: %d" % (len(keys_global), len(dups)))

print("\n=== СОБЫТИЯ ===")
if os.path.isdir(EV):
    for fn in sorted(os.listdir(EV)):
        p = os.path.join(EV, fn)
        ok, raw = read(p)
        text = raw.decode('utf-8-sig')
        ob, cb = text.count('{'), text.count('}')
        ns = re.findall(r'^\s*add_namespace\s*=\s*(\S+)', text, re.M)
        ids = re.findall(r'^\s*id\s*=\s*([A-Za-z0-9_\.]+)', text, re.M)
        bom = raw.startswith(b'\xef\xbb\xbf')
        bad = [i for i in ids if ns and not i.startswith(ns[0] + '.')]
        print("  %-32s ns=%s id=%d braces %d/%d %s BOM=%s"
              % (fn, ns, len(ids), ob, cb, 'OK' if ob == cb else '!!! РАСБАЛАНС', 'да' if bom else 'нет'))
        if ob != cb:
            problems.append("events/%s: дисбаланс скобок %d/%d" % (fn, ob, cb))
        if bad:
            problems.append("events/%s: id вне namespace: %s" % (fn, bad))
        if not ok:
            problems.append("events/%s: не UTF-8" % fn)

print("\n=== ИТОГ ===")
real = []
for x in problems:
    dec = is_accepted(x)
    if dec:
        accepted.append((x, dec))
    else:
        real.append(x)
print("ПРОБЛЕМ: %d" % len(real))
for x in real:
    print("  [P] " + x)
if accepted:
    print("\nПРИНЯТО ВЛАДЕЛЬЦЕМ (не считается проблемой): %d" % len(accepted))
    for x, dec in accepted:
        print("  [A] %s" % x)
        print("      решение: %s" % dec[:150])
print("ПРЕДУПРЕЖДЕНИЙ: %d" % len(warnings))
for x in warnings[:40]:
    print("  [W] " + x)
if len(warnings) > 40:
    print("  ... и ещё %d" % (len(warnings) - 40))
