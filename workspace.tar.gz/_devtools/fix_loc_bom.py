# -*- coding: utf-8 -*-
"""Приводит всю локализацию к UTF-8 with BOM. Идемпотентно, содержимое не меняет."""
import glob, os, hashlib

BOM = b'\xef\xbb\xbf'
targets = sorted(glob.glob('localisation/**/*.yml', recursive=True))
print("=== ПРИВЕДЕНИЕ ЛОКАЛИЗАЦИИ К UTF-8 BOM ===")
for p in targets:
    raw = open(p, 'rb').read()
    body = raw[3:] if raw.startswith(BOM) else raw
    # проверка, что тело — валидный UTF-8
    body.decode('utf-8')
    had = raw.startswith(BOM)
    h_before = hashlib.md5(body).hexdigest()
    with open(p, 'wb') as f:
        f.write(BOM + body)
    raw2 = open(p, 'rb').read()
    h_after = hashlib.md5(raw2[3:]).hexdigest()
    assert raw2.startswith(BOM) and h_before == h_after, p
    print("  %-46s BOM был: %-5s -> добавлен, содержимое идентично (md5 %s), размер %d -> %d"
          % (p, 'да' if had else 'нет', h_before[:8], len(raw), len(raw2)))
print("итого файлов: %d" % len(targets))

print("\n=== ПРОВЕРКА: все yml начинаются с EF BB BF ===")
for p in targets:
    head = open(p, 'rb').read(3)
    print("  %-46s %s  %s" % (p, head.hex(' '), 'OK' if head == BOM else '!!!'))

print("\n=== НЕ-ЛОКАЛИЗАЦИЯ: файлы с не-ASCII без BOM (риск кракозябр в строках скрипта) ===")
found = 0
for p in sorted(glob.glob('**/*.txt', recursive=True) + glob.glob('**/*.gfx', recursive=True)):
    if p.startswith('uploads') or p.startswith('_devtools'):
        continue
    raw = open(p, 'rb').read()
    if raw.startswith(BOM):
        continue
    try:
        txt = raw.decode('utf-8')
    except UnicodeDecodeError:
        print("  [!] %s: НЕ валидный UTF-8" % p)
        found += 1
        continue
    nonascii = [ch for ch in txt if ord(ch) > 127]
    if nonascii:
        # показываем, где именно не-ASCII: в комментариях или в значимых строках
        meaningful = []
        for i, line in enumerate(txt.split('\n'), 1):
            code = line.split('#', 1)[0]
            if any(ord(ch) > 127 for ch in code):
                meaningful.append((i, code.strip()[:80]))
        print("  %-46s не-ASCII символов: %-5d в коде (не в комментариях): %d"
              % (p, len(nonascii), len(meaningful)))
        for i, s in meaningful[:4]:
            print("        строка %d: %s" % (i, s))
        if len(meaningful) > 4:
            print("        ... ещё %d" % (len(meaningful) - 4))
        found += 1
if not found:
    print("  нет")
