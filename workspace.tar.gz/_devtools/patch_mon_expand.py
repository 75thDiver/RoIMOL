# -*- coding: utf-8 -*-
"""ЗЕЛЁНАЯ ВЕТКА v2: три УНИКАЛЬНЫЕ глубокие линии династий (как у красных/синих), без общей развилки."""
import os, shutil, datetime

STAMP = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
BK = os.path.join('_devtools', 'backup_monexp_' + STAMP)
FILES = ['common/national_focus/moldova.txt', 'common/dynamic_modifiers/ROIMOL_ideas.txt']
os.makedirs(BK, exist_ok=True)
for p in FILES:
    shutil.copy2(p, os.path.join(BK, p.replace('/', '__')))
print('бэкап ->', BK)

def read(p): return open(p, encoding='utf-8', newline='').read()
def write(p, s): open(p, 'w', encoding='utf-8', newline='').write(s)

T = '\t'
def F(body):
    out = [T + 'focus = {']
    for line in body.strip('\n').split('\n'):
        out.append((T + T + line) if line else '')
    out.append(T + '}')
    return '\n'.join(out)

P = []
P.append(T + '# ==================== ЗЕЛЁНАЯ ВЕТКА (Монархисты) ====================')
P.append(T + '# Три уникальные линии династий: земская (Богдановичи), дворская (Габсбурги), имперская (Романовы).')

# ---------------- общее начало ----------------
P.append(F('''id = MOL_mon_government
icon = GFX_focus_generic_monarchy_1
prerequisite = { focus = MOL_victory }
x = 38
y = 1
relative_position_id = MOL_victory
cost = 5
search_filters = { FOCUS_FILTER_POLITICAL }
available = { always = no }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tset_country_flag = MOL_mon_path
}'''))
P.append(F('''id = MOL_mon_restoration
icon = GFX_focus_generic_monarchy_2
prerequisite = { focus = MOL_mon_government }
x = 0
y = 1
relative_position_id = MOL_mon_government
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_political_power = 75
\tset_cosmetic_tag = Free_MOL
\tset_party_name = {
\t\tideology = neutrality
\t\tlong_name = MOL_monarchist_party_long
\t\tname = MOL_monarchist_party
\t}
}'''))
P.append(F('''id = MOL_mon_crown
icon = GFX_focus_generic_congress
prerequisite = { focus = MOL_mon_restoration }
x = 0
y = 1
relative_position_id = MOL_mon_restoration
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 100
\tadd_popularity = { ideology = neutrality popularity = 0.15 }
\tset_country_flag = MOL_crown_found
\tcustom_effect_tooltip = MOL_mon_dynasty_choice_tt
}'''))
P.append(T + '\t# === РАЗВИЛКА ДИНАСТИЙ (взаимоисключающие) ===')
P.append(F('''id = MOL_mon_dynasty_native
icon = GFX_focus_generic_monarchy_2
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_habsburg }
mutually_exclusive = { focus = MOL_mon_dynasty_romanov }
x = -6
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_native
\tadd_stability = 0.08
\tadd_political_power = 50
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
\tcustom_effect_tooltip = MOL_mon_dynasty_native_tt
}'''))
P.append(F('''id = MOL_mon_dynasty_habsburg
icon = GFX_focus_generic_treaty
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_native }
mutually_exclusive = { focus = MOL_mon_dynasty_romanov }
x = 0
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_habsburg
\tadd_political_power = 75
\tadd_stability = -0.03
\tevery_other_country = {
\t\tlimit = {
\t\t\tOR = { original_tag = AUS original_tag = HUN original_tag = ROM original_tag = ITA }
\t\t\thas_government = neutrality
\t\t}
\t\tadd_opinion_modifier = { target = ROOT modifier = MOL_trade_agreement }
\t}
\tcustom_effect_tooltip = MOL_mon_dynasty_habsburg_tt
}'''))
P.append(F('''id = MOL_mon_dynasty_romanov
icon = GFX_focus_generic_monarchy_1
prerequisite = { focus = MOL_mon_crown }
mutually_exclusive = { focus = MOL_mon_dynasty_native }
mutually_exclusive = { focus = MOL_mon_dynasty_habsburg }
x = 6
y = 1
relative_position_id = MOL_mon_crown
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
completion_reward = {
\tset_country_flag = MOL_dynasty_romanov
\tadd_war_support = 0.10
\tadd_stability = -0.05
\tadd_manpower = 15000
\tSOV = { add_opinion_modifier = { target = ROOT modifier = MOL_subversive_diplomacy } }
\tcustom_effect_tooltip = MOL_mon_dynasty_romanov_tt
}'''))
P.append(F('''id = MOL_mon_coronation
icon = GFX_focus_rom_royal_dictatorship
prerequisite = { focus = MOL_mon_dynasty_native focus = MOL_mon_dynasty_habsburg focus = MOL_mon_dynasty_romanov }
x = 0
y = 2
relative_position_id = MOL_mon_crown
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.15
\tadd_war_support = 0.10
\tadd_dynamic_modifier = { modifier = MOL_princely_rule }
\tif = {
\t\tlimit = { has_country_flag = MOL_dynasty_native }
\t\tset_party_name = { ideology = neutrality long_name = MOL_bogdanovici_party_long name = MOL_bogdanovici_party }
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Mircea_Bogdan_Voda
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = { ideology = despotism expire = "1970.1.1.1" traits = { bogdanovici_dynasty } }
\t\t}
\t}
\telse_if = {
\t\tlimit = { has_country_flag = MOL_dynasty_habsburg }
\t\tset_party_name = { ideology = neutrality long_name = MOL_habsburg_party_long name = MOL_habsburg_party }
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Leopold_Karl_Habsburg
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = { ideology = despotism expire = "1970.1.1.1" traits = { habsburg_diplomat } }
\t\t}
\t}
\telse_if = {
\t\tlimit = { has_country_flag = MOL_dynasty_romanov }
\t\tset_party_name = { ideology = neutrality long_name = MOL_romanov_party_long name = MOL_romanov_party }
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Tsar_Alexiy_III
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = { ideology = despotism expire = "1970.1.1.1" traits = { romanov_imperial } }
\t\t}
\t}
\telse = {
\t\tadd_country_leader_role = {
\t\t\tcharacter = MOL_Prince
\t\t\tpromote_leader = yes
\t\t\tcountry_leader = { ideology = despotism expire = "1965.1.1.1" traits = { prince_of_moldavia } }
\t\t}
\t}
}'''))

# ================= ЛИНИЯ БОГДАНОВИЧЕЙ (земская) =================
P.append(T + '\t# ==========================================================')
P.append(T + '\t# ЛИНИЯ ДОМА БОГДАНОВИЧЕЙ: земское господарство, церковь и крепость')
P.append(T + '\t# ==========================================================')
P.append(F('''id = MOL_mon_native_sfatul
icon = GFX_focus_generic_improve_the_administration
prerequisite = { focus = MOL_mon_coronation }
x = -8
y = 1
relative_position_id = MOL_mon_coronation
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available = { has_country_flag = MOL_dynasty_native }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_native_dynasty_spirit }
}'''))
P.append(F('''id = MOL_mon_native_land_army
icon = GFX_focus_generic_manpower
prerequisite = { focus = MOL_mon_native_sfatul }
x = 0
y = 1
relative_position_id = MOL_mon_native_sfatul
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 15000
\tadd_stability = 0.05
\tarmy_experience = 50
\tadd_dynamic_modifier = { modifier = MOL_militia_reserves }
}'''))
P.append(F('''id = MOL_mon_orthodox_state
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_native_land_army }
mutually_exclusive = { focus = MOL_mon_historical_claims }
x = -2
y = 1
relative_position_id = MOL_mon_native_land_army
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available = { has_country_flag = MOL_dynasty_native }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_orthodox_state }
}'''))
P.append(F('''id = MOL_mon_historical_claims
icon = GFX_goal_generic_demand_territory
prerequisite = { focus = MOL_mon_native_land_army }
mutually_exclusive = { focus = MOL_mon_orthodox_state }
x = 2
y = 1
relative_position_id = MOL_mon_native_land_army
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available = { has_country_flag = MOL_dynasty_native }
available_if_capitulated = yes
completion_reward = {
\tadd_war_support = 0.15
\tadd_manpower = 20000
\tset_country_flag = MOL_historical_expansion
}'''))
P.append(F('''id = MOL_mon_nobility
icon = GFX_focus_generic_improve_the_administration
prerequisite = { focus = MOL_mon_orthodox_state }
x = 0
y = 1
relative_position_id = MOL_mon_orthodox_state
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_restored_nobility }
}'''))
P.append(F('''id = MOL_mon_native_church_synod
icon = GFX_goal_generic_neutrality_focus
prerequisite = { focus = MOL_mon_nobility }
x = 0
y = 1
relative_position_id = MOL_mon_nobility
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_native_church_autonomy }
}'''))
P.append(F('''id = MOL_mon_cultural_revival
icon = GFX_goal_generic_propaganda
prerequisite = { focus = MOL_mon_native_church_synod }
x = 0
y = 1
relative_position_id = MOL_mon_native_church_synod
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_war_support = 0.05
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
}'''))
P.append(F('''id = MOL_mon_native_fortress
icon = GFX_goal_generic_fortify_city
prerequisite = { focus = MOL_mon_cultural_revival }
x = 0
y = 1
relative_position_id = MOL_mon_cultural_revival
cost = 15
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_war_support = 0.05
\tadd_dynamic_modifier = { modifier = MOL_native_border_fortress }
}'''))
P.append(F('''id = MOL_mon_peaceful_expansion
icon = GFX_goal_generic_improve_relations
prerequisite = { focus = MOL_mon_native_fortress }
x = 0
y = 1
relative_position_id = MOL_mon_native_fortress
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 100
\tif = {
\t\tlimit = { ROM = { is_in_faction = no } }
\t\tcreate_wargoal = { type = puppet_wargoal_goal target = ROM }
\t}
}'''))
P.append(F('''id = MOL_mon_army
icon = GFX_goal_generic_army_doctrines
prerequisite = { focus = MOL_mon_historical_claims }
x = 0
y = 1
relative_position_id = MOL_mon_historical_claims
cost = 15
search_filters = { FOCUS_FILTER_RESEARCH }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 75
\tadd_doctrine_cost_reduction = {
\t\tname = land_doc_bonus
\t\tcost_reduction = 0.5
\t\tuses = 2
\t\tcategory = land_doctrine
\t}
\tadd_manpower = 25000
}'''))
P.append(F('''id = MOL_mon_conquest
icon = GFX_goal_generic_major_war
prerequisite = { focus = MOL_mon_army }
x = 0
y = 1
relative_position_id = MOL_mon_army
cost = 10
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tROM = { exists = yes }
\tNOT = { has_war_with = ROM }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tROM = { exists = no }
\t\towns_state = 79
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_state_claim = 79
\tadd_state_claim = 80
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = ROM
\t\tgenerator = { 79 80 }
\t}
}'''))
P.append(F('''id = MOL_mon_native_land_reform
icon = GFX_focus_generic_workers
prerequisite = { focus = MOL_mon_conquest }
x = 0
y = 1
relative_position_id = MOL_mon_conquest
cost = 10
search_filters = { FOCUS_FILTER_STABILITY FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_manpower = 10000
}'''))
P.append(F('''id = MOL_mon_native_budjak
icon = GFX_focus_generic_resource_extraction
prerequisite = { focus = MOL_mon_native_land_reform }
x = 0
y = 1
relative_position_id = MOL_mon_native_land_reform
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\t766 = {
\t\tadd_extra_state_shared_building_slots = 2
\t\tadd_building_construction = {
\t\t\ttype = infrastructure
\t\t\tlevel = 1
\t\t\tinstant_build = yes
\t\t}
\t}
}'''))
P.append(F('''id = MOL_mon_native_guard
icon = GFX_goal_generic_special_forces
prerequisite = { focus = MOL_mon_native_budjak }
x = 0
y = 1
relative_position_id = MOL_mon_native_budjak
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 10000
\tarmy_experience = 50
\tadd_war_support = 0.05
}'''))
P.append(F('''id = MOL_mon_grand_moldavia
icon = GFX_goal_generic_military_sphere
prerequisite = { focus = MOL_mon_native_guard }
x = 0
y = 1
relative_position_id = MOL_mon_native_guard
cost = 25
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_ANNEXATION }
available_if_capitulated = yes
bypass = {
\tOR = {
\t\towns_state = 79
\t\towns_state = 80
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_stability = 0.10
\tadd_manpower = 50000
\t78 = { add_core_of = ROOT }
\t766 = { add_core_of = ROOT }
\t79 = { add_core_of = ROOT }
\t80 = { add_core_of = ROOT }
\tadd_dynamic_modifier = { modifier = MOL_grand_moldavia }
}'''))

# ================= ЛИНИЯ ГАБСБУРГОВ (дворская) =================
P.append(T + '\t# ==========================================================')
P.append(T + '\t# ЛИНИЯ ГАБСБУРГОВ: двор, Дунайский пакт и торговая империя')
P.append(T + '\t# ==========================================================')
P.append(F('''id = MOL_mon_habsburg_diplomacy
icon = GFX_goal_generic_improve_relations
prerequisite = { focus = MOL_mon_coronation }
x = 0
y = 1
relative_position_id = MOL_mon_coronation
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_RESEARCH }
available = { has_country_flag = MOL_dynasty_habsburg }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 75
\tadd_stability = 0.05
\tadd_dynamic_modifier = { modifier = MOL_habsburg_court }
}'''))
P.append(F('''id = MOL_mon_danubian_pact
icon = GFX_goal_generic_major_alliance
prerequisite = { focus = MOL_mon_habsburg_diplomacy }
x = 0
y = 1
relative_position_id = MOL_mon_habsburg_diplomacy
cost = 20
search_filters = { FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tNOT = { has_war_with = ROM }
}
available_if_capitulated = yes
bypass = { is_faction_leader = yes }
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tif = {
\t\tlimit = { is_in_faction = no }
\t\tcreate_faction = MOL_danubian_pact
\t}
\tif = {
\t\tlimit = { is_faction_leader = yes }
\t\tevery_other_country = {
\t\t\tlimit = {
\t\t\t\tOR = { original_tag = AUS original_tag = HUN original_tag = ROM original_tag = BUL original_tag = GRE original_tag = YUG original_tag = ALB }
\t\t\t\tis_subject = no
\t\t\t\tis_in_faction = no
\t\t\t\tNOT = { has_government = communism }
\t\t\t\tNOT = { has_war_with = ROOT }
\t\t\t}
\t\t\tcountry_event = { id = generic.5 days = 1 }
\t\t}
\t}
\tcustom_effect_tooltip = MOL_mon_danubian_pact_tt
}'''))
P.append(F('''id = MOL_mon_habs_trade_league
icon = GFX_goal_generic_trade
prerequisite = { focus = MOL_mon_danubian_pact }
mutually_exclusive = { focus = MOL_mon_habs_guard_regiments }
x = -2
y = 1
relative_position_id = MOL_mon_danubian_pact
cost = 10
search_filters = { FOCUS_FILTER_INDUSTRY }
available = { has_country_flag = MOL_dynasty_habsburg }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_habs_trade_league }
}'''))
P.append(F('''id = MOL_mon_habs_guard_regiments
icon = GFX_focus_generic_military_mission
prerequisite = { focus = MOL_mon_danubian_pact }
mutually_exclusive = { focus = MOL_mon_habs_trade_league }
x = 2
y = 1
relative_position_id = MOL_mon_danubian_pact
cost = 10
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available = { has_country_flag = MOL_dynasty_habsburg }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 10000
\tarmy_experience = 50
\tadd_war_support = 0.05
}'''))
P.append(F('''id = MOL_mon_habs_railways
icon = GFX_goal_generic_construct_infrastructure
prerequisite = { focus = MOL_mon_habs_trade_league }
x = 0
y = 1
relative_position_id = MOL_mon_habs_trade_league
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\t78 = {
\t\tadd_building_construction = { type = infrastructure level = 1 instant_build = yes }
\t}
\t766 = {
\t\tadd_building_construction = { type = infrastructure level = 1 instant_build = yes }
\t}
\tadd_political_power = 25
}'''))
P.append(F('''id = MOL_mon_habs_industry
icon = GFX_goal_generic_construct_civ_factory
prerequisite = { focus = MOL_mon_habs_railways }
x = 0
y = 1
relative_position_id = MOL_mon_habs_railways
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\trandom_owned_controlled_state = {
\t\tadd_building_construction = { type = industrial_complex level = 1 instant_build = yes }
\t}
\tadd_political_power = 25
}'''))
P.append(F('''id = MOL_mon_habs_academy
icon = GFX_focus_research
prerequisite = { focus = MOL_mon_habs_industry }
x = 0
y = 1
relative_position_id = MOL_mon_habs_industry
cost = 15
search_filters = { FOCUS_FILTER_RESEARCH }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\tadd_dynamic_modifier = { modifier = MOL_habs_court_academy }
}'''))
P.append(F('''id = MOL_mon_habs_marriages
icon = GFX_goal_generic_alliance
prerequisite = { focus = MOL_mon_habs_academy }
x = 0
y = 1
relative_position_id = MOL_mon_habs_academy
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 75
\tAUS = { add_opinion_modifier = { target = ROOT modifier = MOL_favouritism_in_trading } }
\tHUN = { add_opinion_modifier = { target = ROOT modifier = MOL_favouritism_in_trading } }
}'''))
P.append(F('''id = MOL_mon_habs_guarantees
icon = GFX_goal_generic_defence
prerequisite = { focus = MOL_mon_habs_guard_regiments }
x = 0
y = 1
relative_position_id = MOL_mon_habs_guard_regiments
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_political_power = 50
\tevery_other_country = {
\t\tlimit = {
\t\t\tOR = { original_tag = BUL original_tag = GRE original_tag = YUG original_tag = ALB }
\t\t\tis_subject = no
\t\t\tNOT = { has_government = communism }
\t\t\tNOT = { has_war_with = ROOT }
\t\t}
\t\tROOT = { give_guarantee = PREV }
\t}
}'''))
P.append(F('''id = MOL_mon_habs_danube_flotilla
icon = GFX_goal_generic_build_navy
prerequisite = { focus = MOL_mon_habs_guarantees }
x = 0
y = 1
relative_position_id = MOL_mon_habs_guarantees
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tnavy_experience = 50
\t766 = {
\t\tadd_building_construction = { type = dockyard level = 1 instant_build = yes }
\t}
}'''))
P.append(F('''id = MOL_mon_habs_army_corps
icon = GFX_focus_generic_military_academy
prerequisite = { focus = MOL_mon_habs_danube_flotilla }
x = 0
y = 1
relative_position_id = MOL_mon_habs_danube_flotilla
cost = 15
search_filters = { FOCUS_FILTER_RESEARCH FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 50
\tadd_doctrine_cost_reduction = {
\t\tname = land_doc_bonus
\t\tcost_reduction = 0.5
\t\tuses = 1
\t\tcategory = land_doctrine
\t}
}'''))
P.append(F('''id = MOL_mon_habs_danubian_empire
icon = GFX_focus_YUG_unification_of_the_balkans
prerequisite = { focus = MOL_mon_habs_marriages focus = MOL_mon_habs_army_corps }
x = 2
y = 1
relative_position_id = MOL_mon_habs_marriages
cost = 25
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.10
\tadd_political_power = 100
\tadd_dynamic_modifier = { modifier = MOL_danubian_empire }
}'''))

# ================= ЛИНИЯ РОМАНОВЫХ (имперская) =================
P.append(T + '\t# ==========================================================')
P.append(T + '\t# ЛИНИЯ РОМАНОВЫХ: двор в изгнании, Белая армия и Третий Рим')
P.append(T + '\t# ==========================================================')
P.append(F('''id = MOL_mon_romanov_emigre
icon = GFX_goal_generic_allies_build_infantry
prerequisite = { focus = MOL_mon_coronation }
x = 8
y = 1
relative_position_id = MOL_mon_coronation
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 25000
\tadd_war_support = 0.05
\tarmy_experience = 50
\tadd_dynamic_modifier = { modifier = MOL_romanov_court }
}'''))
P.append(F('''id = MOL_mon_romanov_south
icon = GFX_focus_attack_soviet
prerequisite = { focus = MOL_mon_romanov_emigre }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_emigre
cost = 15
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tSOV = { exists = yes }
\tNOT = { has_war_with = SOV }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tSOV = { exists = no }
\t\towns_state = 192
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_state_claim = 192
\tadd_state_claim = 196
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = SOV
\t\tgenerator = { 192 196 }
\t}
}'''))
P.append(F('''id = MOL_mon_romanov_white_army
icon = GFX_focus_generic_limited_social_mobilization
prerequisite = { focus = MOL_mon_romanov_south }
mutually_exclusive = { focus = MOL_mon_romanov_third_rome }
x = -2
y = 1
relative_position_id = MOL_mon_romanov_south
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_manpower = 20000
\tadd_dynamic_modifier = { modifier = MOL_white_army }
}'''))
P.append(F('''id = MOL_mon_romanov_third_rome
icon = GFX_goal_generic_national_unity
prerequisite = { focus = MOL_mon_romanov_south }
mutually_exclusive = { focus = MOL_mon_romanov_white_army }
x = 2
y = 1
relative_position_id = MOL_mon_romanov_south
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_STABILITY }
available = { has_country_flag = MOL_dynasty_romanov }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_war_support = 0.05
\tadd_dynamic_modifier = { modifier = MOL_third_rome }
}'''))
P.append(F('''id = MOL_mon_romanov_cossacks
icon = GFX_goal_generic_small_arms
prerequisite = { focus = MOL_mon_romanov_white_army }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_white_army
cost = 15
search_filters = { FOCUS_FILTER_MANPOWER FOCUS_FILTER_ARMY_XP }
available_if_capitulated = yes
completion_reward = {
\tarmy_experience = 50
\tadd_manpower = 10000
\tadd_dynamic_modifier = { modifier = MOL_cossack_hosts }
}'''))
P.append(F('''id = MOL_mon_romanov_war_industry
icon = GFX_goal_generic_construct_mil_factory
prerequisite = { focus = MOL_mon_romanov_cossacks }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_cossacks
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tadd_war_support = 0.05
\trandom_owned_controlled_state = {
\t\tadd_building_construction = { type = arms_factory level = 1 instant_build = yes }
\t}
}'''))
P.append(F('''id = MOL_mon_romanov_black_sea_fleet
icon = GFX_goal_generic_navy_cruiser
prerequisite = { focus = MOL_mon_romanov_war_industry }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_war_industry
cost = 15
search_filters = { FOCUS_FILTER_INDUSTRY }
available_if_capitulated = yes
completion_reward = {
\tnavy_experience = 50
\t766 = {
\t\tadd_building_construction = { type = dockyard level = 1 instant_build = yes }
\t}
}'''))
P.append(F('''id = MOL_mon_romanov_orthodoxy
icon = GFX_goal_generic_propaganda
prerequisite = { focus = MOL_mon_romanov_third_rome }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_third_rome
cost = 10
search_filters = { FOCUS_FILTER_POLITICAL }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_political_power = 50
\tadd_popularity = { ideology = neutrality popularity = 0.10 }
}'''))
P.append(F('''id = MOL_mon_romanov_southern_claims
icon = GFX_goal_generic_demand_territory
prerequisite = { focus = MOL_mon_romanov_orthodoxy }
x = 0
y = 1
relative_position_id = MOL_mon_romanov_orthodoxy
cost = 15
search_filters = { FOCUS_FILTER_ANNEXATION FOCUS_FILTER_POLITICAL }
available = {
\tis_subject = no
\tSOV = { exists = yes }
\tNOT = { has_war_with = SOV }
}
available_if_capitulated = yes
bypass = {
\tOR = {
\t\tSOV = { exists = no }
\t\towns_state = 197
\t}
}
completion_reward = {
\tadd_war_support = 0.10
\tadd_state_claim = 197
\tadd_state_claim = 137
\tcreate_wargoal = {
\t\ttype = take_state_focus
\t\ttarget = SOV
\t\tgenerator = { 197 137 }
\t}
}'''))
P.append(F('''id = MOL_mon_romanov_imperial_throne
icon = GFX_focus_rom_royal_dictatorship
prerequisite = { focus = MOL_mon_romanov_black_sea_fleet focus = MOL_mon_romanov_southern_claims }
x = 2
y = 1
relative_position_id = MOL_mon_romanov_black_sea_fleet
cost = 25
search_filters = { FOCUS_FILTER_POLITICAL FOCUS_FILTER_MANPOWER }
available_if_capitulated = yes
completion_reward = {
\tadd_stability = 0.05
\tadd_war_support = 0.10
\tadd_manpower = 50000
\tadd_dynamic_modifier = { modifier = MOL_imperial_throne }
}'''))

NEW_BRANCH = '\n'.join(P)

p = 'common/national_focus/moldova.txt'
s = read(p)
marker = T + '# ==================== ЗЕЛЁНАЯ ВЕТКА (Монархисты) ===================='
i = s.index(marker)
end = s.rindex('\n}')          # закрывающая скобка focus_tree
s = s[:i] + NEW_BRANCH + s[end:]
write(p, s)
print('[OK] moldova.txt: зелёная ветка v2 (%d фокусов), общая развилка убрана' % len([x for x in P if x.startswith(T + 'focus')]))

# ---------------- новые динамические модификаторы ----------------
p = 'common/dynamic_modifiers/ROIMOL_ideas.txt'
s = read(p)
NEW_DM = '''
# === Нацдухи линий зелёной ветки (v2) ===
MOL_native_church_autonomy = {
\ticon = "GFX_idea_generic_neutrality_drift_bonus"
\tenable = { always = yes }
\tstability_factor = 0.05
\tpolitical_power_gain = 0.10
\tdrift_defence_factor = 0.3
\tmonthly_population = 0.03
}

MOL_native_border_fortress = {
\ticon = "GFX_idea_generic_fortification"
\tenable = { always = yes }
\tarmy_core_defence_factor = 0.15
\tattrition = -0.10
\tsurrender_limit = 0.05
}

MOL_habs_trade_league = {
\ticon = "GFX_idea_generic_trade"
\tenable = { always = yes }
\ttrade_opinion_factor = 0.15
\tconsumer_goods_factor = -0.05
\tproduction_speed_buildings_factor = 0.05
\tmin_export = 0.05
}

MOL_habs_court_academy = {
\ticon = "GFX_idea_generic_spy_intel"
\tenable = { always = yes }
\tresearch_speed_factor = 0.07
\tpolitical_power_factor = 0.05
\tstability_factor = 0.03
}

MOL_danubian_empire = {
\ticon = "GFX_idea_habsburg_empire"
\tenable = { always = yes }
\tstability_factor = 0.10
\tpolitical_power_factor = 0.10
\tindustrial_capacity_factory = 0.10
\tarmy_core_defence_factor = 0.05
\tconsumer_goods_factor = -0.03
}

MOL_white_army = {
\ticon = "GFX_idea_generic_army_war_college"
\tenable = { always = yes }
\tarmy_org_factor = 0.08
\ttraining_time_factor = -0.10
\tarmy_attack_factor = 0.05
\tconscription_factor = 0.05
}

MOL_cossack_hosts = {
\ticon = "GFX_idea_extensive_conscription"
\tenable = { always = yes }
\tarmy_speed_factor = 0.05
\tarmy_org_factor = 0.03
\tattrition = -0.05
}

MOL_third_rome = {
\ticon = "GFX_idea_generic_political_unity"
\tenable = { always = yes }
\tstability_factor = 0.05
\twar_support_factor = 0.10
\tdrift_defence_factor = 0.4
\tjustify_war_goal_time = -0.10
}

MOL_imperial_throne = {
\ticon = "GFX_idea_generic_central_management"
\tenable = { always = yes }
\tarmy_attack_factor = 0.10
\tarmy_defence_factor = 0.10
\tconscription = 0.02
\tsurrender_limit = 0.15
\twar_support_factor = 0.10
\tconsumer_goods_factor = 0.05
}
'''
if 'MOL_native_church_autonomy' not in s:
    if not s.endswith('\n'):
        s += '\n'
    s += NEW_DM
    write(p, s)
    print('[OK] dynamic_modifiers: +9 нацдухов линий')
else:
    print('[--] уже есть')
