# -*- coding: utf-8 -*-
"""Точечная проверка экономики решений: cost vs add_political_power (двойное списание),
days_remove + complete/remove_effect, расход vs выдача снаряжения."""
import re, glob, os

def strip_comments(t):
    out = []
    for line in t.split("\n"):
        res, inq = [], False
        for ch in line:
            if ch == '"':
                inq = not inq
            if ch == '#' and not inq:
                break
            res.append(ch)
        out.append("".join(res))
    return "\n".join(out)

def split_decisions(text):
    """Возвращает [(cat, dec, body)] по уровням вложенности 1/2."""
    res, depth, cat, dec, buf = [], 0, None, None, []
    for line in text.split("\n"):
        opens, closes = line.count("{"), line.count("}")
        if depth == 1 and opens and not closes:
            m = re.match(r"\s*([A-Za-z0-9_]+)\s*=\s*\{", line)
            if m:
                dec = m.group(1)
                buf = []
        if dec is not None:
            buf.append(line)
        depth += opens - closes
        if depth == 1 and dec is not None and closes and not opens:
            res.append((cat, dec, "\n".join(buf)))
            dec = None
        if depth == 0:
            m = re.match(r"\s*([A-Za-z0-9_]+)\s*=\s*\{", line)
            cat = m.group(1) if m and opens else cat
            if depth == 0 and cat is None and opens:
                pass
    return res

def section(body, name):
    m = re.search(r"^\s*%s\s*=\s*\{(.*?)^\s*\}" % name, body, re.S | re.M)
    return m.group(1) if m else ""

rows = []
for p in sorted(glob.glob("common/decisions/*.txt")):
    t = strip_comments(open(p, encoding="utf-8-sig").read())
    # простой проход: ищем блоки решений на любом отступе
    lines = t.split("\n")
    depth = 0
    stack = []
    cur = None
    for line in lines:
        m = re.match(r"(\s*)([A-Za-z0-9_]+)\s*=\s*\{", line)
        opens, closes = line.count("{"), line.count("}")
        if m and opens > closes:
            stack.append((m.group(2), depth))
        depth += opens - closes
        while stack and depth <= stack[-1][1]:
            stack.pop()
    # второй проход: собираем тела решений по регулярке "блок с отступом 2 уровня"
    for mm in re.finditer(r"^([ \t]{1,8})([A-Za-z0-9_]+)\s*=\s*\{(.*?)^\1\}", t, re.S | re.M):
        body = mm.group(3)
        if "icon" not in body and "cost" not in body and "days_remove" not in body and "activation" not in body:
            continue
        rows.append((os.path.basename(p), mm.group(2), body))

print("%-40s %-8s %-10s %-9s %-9s %s" % ("РЕШЕНИЕ", "cost", "PP в эфф.", "ИТОГО PP", "days_rm", "СНАРЯЖЕНИЕ"))
double = []
for f, did, body in sorted(rows, key=lambda x: (x[0], x[1])):
    cost = re.search(r"^\s*cost\s*=\s*([-\d.]+)", body, re.M)
    cost_v = float(cost.group(1)) if cost else 0.0
    pps = [float(x) for x in re.findall(r"add_political_power\s*=\s*([-\d.]+)", body)]
    pp_neg = sum(x for x in pps if x < 0)
    dr = re.search(r"days_remove\s*=\s*(\d+)", body)
    eq_out = re.findall(r"add_equipment_to_stockpile\s*=\s*\{\s*type\s*=\s*(\S+)\s+amount\s*=\s*([-\d.]+)", body)
    eq_req = re.findall(r"has_equipment\s*=\s*\{\s*(\S+)\s*>\s*([\d.]+)", body)
    total = cost_v + (-pp_neg)
    flag = ""
    if cost_v and pp_neg:
        flag = "  <<< ДВОЙНОЕ СПИСАНИЕ"
        double.append((f, did, cost_v, pp_neg, total))
    print("%-40s %-8s %-10s %-9s %-9s +%s / требует %s%s"
          % (did, cost_v or "-", pp_neg or "-", total or "-", dr.group(1) if dr else "-",
             eq_out if eq_out else "-", eq_req if eq_req else "-", flag))
    if eq_req and eq_out and all(float(a) > 0 for _, a in eq_out):
        print("     ^^ требует %s в наличии, но в эффектах СНЯТИЯ выдаёт +%s на склад (а не расходует)"
              % (eq_req, eq_out))

print("\n=== ДВОЙНОЕ СПИСАНИЕ PP: %d решений ===" % len(double))
for f, did, c, pp, tot in double:
    print("  %-38s cost=%-6s add_political_power=%-6s фактически=%-6s (%s)" % (did, c, pp, tot, f))

print("\n=== прочие проверки ===")
for f, did, body in rows:
    miss = []
    if re.search(r"days_remove", body) and not re.search(r"remove_effect", body):
        miss.append("days_remove без remove_effect")
    if re.search(r"^\s*complete_effect", body, re.M) and not re.search(r"days_remove", body):
        pass
    if not re.search(r"\ballowed\b", body):
        miss.append("нет allowed")
    if not re.search(r"\bavailable\b", body) and not re.search(r"activation", body):
        miss.append("нет available")
    if miss:
        print("  %-38s %s" % (did, "; ".join(miss)))
