# -*- coding: utf-8 -*-
"""Аудит common/characters, common/countries, common/country_tags, common/country_leader."""
import os, re, glob, collections

issues, notes = [], []

def clean(t):
    return re.sub(r'#.*', '', t)

def braces(t):
    return t.count('{'), t.count('}')

def readb(p):
    raw = open(p, 'rb').read()
    try:
        raw.decode('utf-8'); ok = True
    except Exception:
        ok = False
    return ok, raw

print("=== ФАЙЛЫ common/{characters,countries,country_tags,country_leader} ===")
files = []
for d in ("common/characters", "common/countries", "common/country_tags", "common/country_leader"):
    files += sorted(glob.glob(os.path.join(d, "*.txt")))
for p in files:
    ok, raw = readb(p)
    t = raw.decode('utf-8-sig')
    o, c = braces(clean(t))
    bom = raw.startswith(b'\xef\xbb\xbf')
    crlf = b'\r\n' in raw
    nl_end = raw.endswith(b'\n')
    print("  %-42s braces %3d/%-3d %-4s BOM=%-5s CRLF=%-5s UTF8=%-5s newline_at_eof=%s"
          % (p, o, c, 'OK' if o == c else '!!!', bom, crlf, ok, nl_end))
    if o != c: issues.append("%s: дисбаланс скобок %d/%d" % (p, o, c))
    if not ok: issues.append("%s: не UTF-8" % p)
    if not nl_end: notes.append("%s: нет перевода строки в конце файла" % p)

print("\n=== COUNTRY_TAGS: зарегистрированные теги ===")
reg = {}
for p in sorted(glob.glob("common/country_tags/*.txt")):
    t = clean(open(p, encoding='utf-8-sig').read())
    for m in re.finditer(r'^\s*([A-Za-z0-9_]+)\s*=\s*"([^"]+)"', t, re.M):
        tag, path = m.group(1), m.group(2)
        reg[tag] = (p, path)
        print("  %s -> %s   (%s)" % (tag, path, p))
        if not os.path.isfile(os.path.join("common", path)):
            issues.append("country_tags: %s ссылается на ОТСУТСТВУЮЩИЙ common/%s" % (tag, path))

print("\n=== common/countries/: файлы без регистрации тега ===")
for p in sorted(glob.glob("common/countries/*.txt")):
    base = os.path.basename(p)
    referenced = [t for t, (src, path) in reg.items() if os.path.basename(path) == base]
    t = clean(open(p, encoding='utf-8-sig').read())
    gc = re.search(r'graphical_culture\s*=\s*(\S+)', t)
    gc2 = re.search(r'graphical_culture_2d\s*=\s*(\S+)', t)
    col = re.search(r'color\s*=\s*rgb\s*\{\s*(\d+)\s+(\d+)\s+(\d+)\s*\}', t)
    print("  %-34s tag=%-22s gfx=%s 2d=%s color=%s"
          % (base, referenced if referenced else "НЕ ЗАРЕГИСТРИРОВАН",
             gc.group(1) if gc else '-', gc2.group(1) if gc2 else '-',
             "%s %s %s" % col.groups() if col else '-'))
    if not referenced:
        notes.append("common/countries/%s не упоминается ни в одном country_tags/*" % base)

print("\n=== common/country_leader/traits.txt: трейты ===")
tp = "common/country_leader/traits.txt"
trait_defs = []
if os.path.isfile(tp):
    t = clean(open(tp, encoding='utf-8-sig').read())
    trait_defs = re.findall(r'^\s*([a-z0-9_]+)\s*=\s*\{', t, re.M)
    print("  определено: %s" % trait_defs)
    for tr in trait_defs:
        blk = re.search(re.escape(tr) + r'\s*=\s*\{(.*?)\n\}', t, re.S)
        if blk:
            mods = re.findall(r'^\s*([a-z_0-9]+)\s*=\s*(-?[\d.]+)', blk.group(1), re.M)
            print("    %-24s %s" % (tr, mods))
loc_traits = set()
lp = "localisation/russian/RoIMOL_traits_l_russian.yml"
if os.path.isfile(lp):
    loc_traits = set(re.findall(r'^\s*([a-z0-9_]+)(?::\d*)?\s*:', open(lp, encoding='utf-8-sig').read(), re.M))
for tr in trait_defs:
    if tr not in loc_traits:
        issues.append("трейт %s не имеет ключа локализации" % tr)
    if tr + "_desc" not in loc_traits:
        notes.append("трейт %s: нет %s_desc в локализации" % (tr, tr))

print("\n=== common/characters/MOL.txt ===")
cp = "common/characters/MOL.txt"
ct = clean(open(cp, encoding='utf-8-sig').read())
ids = re.findall(r'^\t([A-Za-z0-9_]+)\s*=\s*\{', ct, re.M)
dups = [k for k, v in collections.Counter(ids).items() if v > 1]
print("  всего персонажей: %d" % len(ids))
print("  дубли id: %s" % (dups if dups else "нет"))
for d in dups:
    issues.append("characters: дубль id %s" % d)

names = re.findall(r'name\s*=\s*"([^"]+)"', ct)
print("  name= значений: %d (совпадают с id: %s)" % (len(names), all(n in ids for n in names)))

# роли
roles = collections.Counter()
for r in ('country_leader', 'advisor', 'corps_commander', 'navy_leader', 'field_marshal', 'operatives'):
    roles[r] = len(re.findall(r'\b%s\s*=\s*\{' % r, ct))
print("  роли: %s" % dict(roles))

# идеологии лидеров
ideol = collections.Counter(re.findall(r'\bidiology\s*=\s*(\w+)', ct))
print("  ideology= у лидеров: %s" % dict(ideol))

# трейты у лидеров/советников
used_traits = set(re.findall(r'^\s*([a-z0-9_]+)\s*$', ct, re.M))
tr_blocks = re.findall(r'traits\s*=\s*\{(.*?)\}', ct, re.S)
all_traits = set()
for b in tr_blocks:
    all_traits |= set(re.findall(r'[a-z0-9_]+', b))
print("  трейтов использовано: %d" % len(all_traits))
custom_used = sorted(all_traits & set(trait_defs))
print("  из них наших (country_leader/traits.txt): %s" % custom_used)
for tr in trait_defs:
    if tr not in all_traits:
        notes.append("трейт %s определён, но нигде не выдан в characters" % tr)

# gfx / портреты
gfx = sorted(set(re.findall(r'"?(gfx/[A-Za-z0-9_/\.\-]+)"?', ct)))
print("  путей gfx в портретах: %d" % len(gfx))
for g in gfx[:12]:
    print("     %s" % g)
if len(gfx) > 12:
    print("     ... ещё %d" % (len(gfx) - 12))
generic = [g for g in gfx if 'Generic' in g or 'generic' in g]
print("  generic-портретов: %d" % len(generic))
todos = ct.count('TODO')
print("  TODO-меток (Missing large portrait и т.п.): %d" % todos)

# сверка с recruit_character
hist = clean(open("history/countries/MOL - Moldova.txt", encoding='utf-8-sig').read())
rec = re.findall(r'recruit_character\s*=\s*(\w+)', hist)
missing = [r for r in rec if r not in ids]
unused = [i for i in ids if i not in rec]
print("\n  recruit_character в history: %d" % len(rec))
print("  НЕТ в characters: %s" % (missing if missing else "-"))
print("  есть в characters, но НЕ рекрутированы: %s" % (unused if unused else "-"))
for m in missing:
    issues.append("recruit_character = %s — персонаж не определён в common/characters/MOL.txt" % m)

# локализация персонажей
loc_all = set()
for lp2 in glob.glob("localisation/russian/*.yml"):
    loc_all |= set(re.findall(r'^\s*([A-Za-z0-9_\.]+)(?::\d*)?\s*:', open(lp2, encoding='utf-8-sig').read(), re.M))
noloc = [i for i in ids if i not in loc_all]
print("\n  персонажей без ключа локализации: %d из %d" % (len(noloc), len(ids)))
print("     %s" % (", ".join(noloc) if noloc else "-"))
notes.append("characters: %d id без ключей локализации (имена отобразятся как id)" % len(noloc))

print("\n=== ИТОГ ===")
print("ПРОБЛЕМ: %d" % len(issues))
for x in issues: print("  [P] " + x)
print("ЗАМЕТОК: %d" % len(notes))
for x in notes: print("  [N] " + x)
