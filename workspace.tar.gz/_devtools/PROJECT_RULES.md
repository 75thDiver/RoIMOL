# RoIMOL — постоянные правила работы (standing rules)

Обновлено: 2026-09-18. Файл лежит вне дерева мода (`_devtools/`), в упаковку не попадает.

## 1. Формат отчёта о ЛЮБЫХ изменениях (обязательно, всегда)
Каждый ответ, в котором я что-то менял в проекте, **обязан содержать таблицу изменённых файлов**:

| Файл | Что изменено | Было | Стало |
|---|---|---|---|
| точный путь от корня мода | краткая суть правки | размер/строки/число объектов | размер/строки/число объектов |

Плюс отдельной строкой или второй таблицей — служебные файлы (бэкапы, скрипты, конспекты), если они создавались.
Правило введено владельцем 2026-09-18 и действует впредь без напоминаний.

## 2. Протокол приёма файлов (из стартового промпта, действует)
- На сообщение с файлами отвечать строго: «Принято: [пути]. Целостность: [ок/проблемы]. Жду подтверждения переноса.»
- Записывать каждый файл в реестр (путь → статус), ничего не анализировать до подтверждения.
- Подтверждение переноса получено **2026-09-18** (ответ владельца «Подтверждаю, начинай» через ask_user, вопрос `gate` → `full`). Обычный рабочий режим: правки файлами/диффами + отчёт «что / где / зачем / риски» + таблица из п.1.

## 3. Архитектурные ограничения проекта (не нарушать)
- Нацдухи — **только** `common/dynamic_modifiers/` и только `add_dynamic_modifier` / `has_dynamic_modifier` / `remove_dynamic_modifier`. `add_ideas` / `has_idea` для них запрещены.
- Одно фокус-дерево: `id = moldova_focus`, `default = yes` — **ровно одно на всю игру**. Вторые деревья и бэкапы `.txt` внутри `common/national_focus/` запрещены.
- Бэкапы и служебные файлы — только в `_devtools/` (вне дерева мода). Файлы `.txt` внутри папок мода игра грузит как контент.
- Локализация — только `localisation/russian/`, **UTF-8 with BOM** (приведено 2026-09-18, скрипт `_devtools/fix_loc_bom.py`). Каждому новому объекту — ключ и `_desc`.
- Иконки: использовать только заведомо существующие ванильные GFX. Известно битые: `GFX_goal_generic_neutrality`, `GFX_focus_generic_agrarian_reform`, `GFX_focus_generic_diplomatic_mission`, `GFX_focus_generic_infrastructure_2`, `GFX_focus_generic_declare_war`, `GFX_focus_generic_standing_army`. Заведомо валидные (подтверждены владельцем): `GFX_goal_generic_neutrality_focus`, `GFX_goal_generic_major_war`, `GFX_goal_generic_military_sphere`. Полный список используемых спрайтов: `_devtools/report_gfx_to_verify.txt`.
- Решения — внутри блока своей категории; метаданные категорий — в `common/decisions/categories/`.
- Чужие моды (better_yugo и т.п.) — только референс механик, не копировать.

## 4. Принятые владельцем решения (не предлагать повторно, не «чинить» молча)
Реестр: `_devtools/accepted_issues.json` (читается аудиторскими скриптами).
- Незакрытые внутренние кавычки в `moldavia.3.d` и `MOL_bessarabia_reform_bunkers_desc` — **не трогать**.
- Пустая первая строка в `RoIMOL_ideas_l_russian.yml` — **не трогать**.
- BOM в скриптовые `.txt`/`.gfx` не добавлять (только локализация).
- Графика не передаётся: работа по перечню, бинарники не ждём.

## 5. Источники истины при сомнении в синтаксисе
1. Вики Paradox (`hoi4.paradoxwikis.com`) — приоритет.
2. `_devtools/hoi4-modding-skills/docs/` — `01_effects/effects.json` (439), `04_triggers/triggers.json` (495), `00_coding_contexts/*` (modifiers, effects, triggers, variables, console).
3. `_devtools/hoi4-modding-skills/skills/*/SKILL.md` — шпаргалки; **могут ошибаться** (см. п.6).
4. `_devtools/wiki/*.md` — мои конспекты: modding-индекс, страны/теги, дипломатия и марионетки, правительство, UI, события (цепочка по Бессарабии), дивизии, focus-эррата, портреты.
Неуверенность помечать явно словами «uncertainty» + способ проверки.

## 6. Известные ошибки в сторонних справочниках (эррата)
- `hoi4-nf-creator/references/nf_structure.md` описывает `prerequisite` **наоборот**. Правильно по вики: несколько `focus =` в одном блоке = **OR**, несколько отдельных блоков `prerequisite` = **AND**. Подробности: `_devtools/wiki/07_focus_modding_errata.md`.

## 7. Ключевые факты о проекте (проверено)
- `MOL` — **ванильный releasable-тег** (Молдова): регистрировать в `country_tags` не нужно; `history/countries/MOL - Moldova.txt` переопределяет ванильный файл.
- `PMR` — свободный тег, зарегистрирован в `common/country_tags/01_ROIMOL_countries.txt`.
- Косметические теги (`Free_MOL`, `MOL_Bessarabian_Tinut`, `ROM_MOL_autonomic_state`, `MOL_balkan_union`, `MOL_moldavian_ssr`, `MOL_peoples_republic`) регистрации не требуют; цвета — в `common/countries/cosmetic.txt`; флаги — обязательно идеологические (`TAG_ideology.tga`).
- Цепочка по Бессарабии в ванили: `soviet.30` / `SOV_claim_on_bessarabia` → `romania.1` → `soviet.4` (уступила, флаг `bessarabia_ceded`) / `soviet.5` (отказ + Conquer-CB на 78).
