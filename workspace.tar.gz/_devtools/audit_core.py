# -*- coding: utf-8 -*-
"""Комплексный аудит: national_focus, dynamic_modifiers, ideas, opinion_modifiers, names, units, gfx."""
import os, re, glob, json, collections

issues, notes = [], []

def rd(p):
    raw = open(p, 'rb').read()
    try:
        raw.decode('utf-8'); ok = True
    except Exception:
        ok = False
    return ok, raw

def strip_comments(t):
    out = []
    for line in t.split('\n'):
        res, inq = [], False
        for ch in line:
            if ch == '"':
                inq = not inq
            if ch == '#' and not inq:
                break
            res.append(ch)
        out.append(''.join(res))
    return '\n'.join(out)

# ---------- локализация ----------
loc = {}
for p in glob.glob('localisation/russian/*.yml'):
    for m in re.finditer(r'^\s*([A-Za-z0-9_.]+)(?::\d*)?\s*:', open(p, encoding='utf-8-sig').read(), re.M):
        loc.setdefault(m.group(1), os.path.basename(p))

# ---------- спрайты, объявленные в interface/*.gfx ----------
sprites = set()
for p in glob.glob('interface/*.gfx'):
    t = open(p, encoding='utf-8-sig').read()
    sprites |= set(re.findall(r'name\s*=\s*"([^"]+)"', t))
textures = set()
for p in glob.glob('interface/*.gfx'):
    t = open(p, encoding='utf-8-sig').read()
    textures |= set(re.findall(r'texturefile\s*=\s*"([^"]+)"', t))

BAD_ICONS = {"GFX_goal_generic_neutrality", "GFX_focus_generic_agrarian_reform",
             "GFX_focus_generic_diplomatic_mission", "GFX_focus_generic_infrastructure_2",
             "GFX_focus_generic_declare_war", "GFX_focus_generic_standing_army"}

# ================= FOCUS TREE =================
print("=" * 70)
print("FOCUS TREE")
print("=" * 70)
fp = 'common/national_focus/moldova.txt'
ok, raw = rd(fp)
t = raw.decode('utf-8-sig')
clean = strip_comments(t)
o, c = clean.count('{'), clean.count('}')
print("файл: %d строк, %d байт, BOM=%s, CRLF=%s, скобки %d/%d %s"
      % (t.count('\n') + 1, len(raw), raw.startswith(b'\xef\xbb\xbf'), b'\r\n' in raw, o, c,
         'OK' if o == c else '!!!'))
if o != c: issues.append('focus tree: дисбаланс скобок %d/%d' % (o, c))
print("focus_tree блоков: %d; default = yes: %d; id = moldova_focus: %d"
      % (len(re.findall(r'^\s*focus_tree\s*=\s*\{', clean, re.M)),
         len(re.findall(r'^\s*default\s*=\s*yes', clean, re.M)),
         len(re.findall(r'^\s*id\s*=\s*moldova_focus\b', clean, re.M))))
if len(re.findall(r'^\s*default\s*=\s*yes', clean, re.M)) != 1:
    issues.append('focus tree: default = yes встречается != 1 раз')

# парсим фокусы
focuses = {}
lines = clean.split('\n')
depth = 0
in_focus = False
cur = None
buf = []
start_line = 0
for ln, line in enumerate(lines, 1):
    op, cl = line.count('{'), line.count('}')
    m = re.match(r'^(\s*)focus\s*=\s*\{', line)
    if m and not in_focus:
        in_focus, buf, start_line, fdepth = True, [], ln, depth
    if in_focus:
        buf.append(line)
    depth += op - cl
    if in_focus and depth <= fdepth:
        body = '\n'.join(buf)
        fid = re.search(r'^\s*id\s*=\s*([A-Za-z0-9_]+)', body, re.M)
        if fid:
            k = fid.group(1)
            if k in focuses:
                issues.append('ДУБЛЬ id фокуса: %s (строки %d и %d)' % (k, focuses[k][1], start_line))
            focuses[k] = (body, start_line)
        else:
            issues.append('focus-блок на строке %d без id' % start_line)
        in_focus = False
print("фокусов: %d; уникальных id: %d" % (len(focuses) + len([1 for i in issues if 'ДУБЛЬ id фокуса' in i]), len(focuses)))

# ссылки
allids = set(focuses)
missing_refs = collections.defaultdict(list)
for k, (body, ln) in focuses.items():
    for field in ('prerequisite', 'mutually_exclusive', 'relative_position_id'):
        for m in re.finditer(r'%s\s*=\s*\{([^}]*)\}' % field, body):
            for ref in re.findall(r'focus\s*=\s*([A-Za-z0-9_]+)', m.group(1)):
                if ref not in allids:
                    missing_refs[ref].append('%s (%s, строка %d)' % (k, field, ln))
        for m in re.finditer(r'%s\s*=\s*([A-Za-z0-9_]+)' % field, body):
            ref = m.group(1)
            if ref not in allids and ref != field:
                missing_refs[ref].append('%s (%s, строка %d)' % (k, field, ln))
print("\nссылки на несуществующие фокусы: %d" % len(missing_refs))
for ref, wh in sorted(missing_refs.items()):
    print("  [!] %-40s <- %s" % (ref, '; '.join(wh[:3]) + (' ...' if len(wh) > 3 else '')))
    issues.append('фокус %s ссылается на несуществующий %s' % (wh[0].split(' ')[0], ref))

# координаты
pos = collections.defaultdict(list)
for k, (body, ln) in focuses.items():
    x = re.search(r'^\s*x\s*=\s*(-?\d+)', body, re.M)
    y = re.search(r'^\s*y\s*=\s*(-?\d+)', body, re.M)
    rel = re.search(r'^\s*relative_position_id\s*=\s*([A-Za-z0-9_]+)', body, re.M)
    if x and y:
        pos[(rel.group(1) if rel else 'ABS', int(x.group(1)), int(y.group(1)))].append(k)
dups = {p: v for p, v in pos.items() if len(v) > 1}
print("\nпересечения координат (x,y): %d" % len(dups))
for p, v in sorted(dups.items(), key=lambda z: str(z[0])):
    print("  [!] %s -> %s" % (p, v))
    issues.append('пересечение координат %s: %s' % (p, v))
noflags = [k for k, (b, l) in focuses.items() if not re.search(r'^\s*x\s*=', b, re.M)]
print("фокусов без x/y: %d %s" % (len(noflags), noflags[:8]))

# локализация
noloc = [k for k in focuses if k not in loc]
nodesc = [k for k in focuses if k + '_desc' not in loc]
print("\nбез loc-ключа: %d; без _desc: %d" % (len(noloc), len(nodesc)))
if noloc: print("  БЕЗ ИМЕНИ: %s" % noloc)
if nodesc: print("  БЕЗ _desc: %s" % (nodesc[:30] + (['...'] if len(nodesc) > 30 else [])))
for k in noloc: issues.append('фокус %s без ключа локализации' % k)
for k in nodesc: notes.append('фокус %s без %s_desc' % (k, k))

# иконки
icons = collections.Counter()
for k, (body, ln) in focuses.items():
    m = re.search(r'^\s*icon\s*=\s*([A-Za-z0-9_]+)', body, re.M)
    if m:
        icons[m.group(1)] += 1
    else:
        notes.append('фокус %s без icon' % k)
print("\nиконок уникальных: %d (всего присвоений %d)" % (len(icons), sum(icons.values())))
bad = [i for i in icons if i in BAD_ICONS]
print("  из чёрного списка (грабли №2): %s" % (bad if bad else 'нет'))
for i in bad: issues.append('битая ванильная иконка %s в дереве (x%d)' % (i, icons[i]))
own = [i for i in icons if i in sprites]
print("  наши спрайты из interface/*.gfx: %s" % own)
pref = collections.Counter(i.split('_')[1] if i.startswith('GFX_') and len(i.split('_')) > 1 else '?' for i in icons)
print("  префиксы: %s" % dict(pref))

# эффекты дерева
dyn = collections.Counter(re.findall(r'add_dynamic_modifier\s*=\s*\{\s*modifier\s*=\s*([A-Za-z0-9_]+)', clean))
dynrm = collections.Counter(re.findall(r'remove_dynamic_modifier\s*=\s*\{\s*modifier\s*=\s*([A-Za-z0-9_]+)', clean))
dynhas = collections.Counter(re.findall(r'has_dynamic_modifier\s*=\s*\{\s*modifier\s*=\s*([A-Za-z0-9_]+)', clean))
addideas = collections.Counter(re.findall(r'add_ideas\s*=\s*([A-Za-z0-9_]+)', clean))
timedidea = collections.Counter(re.findall(r'add_timed_idea\s*=\s*\{\s*idea\s*=\s*([A-Za-z0-9_]+)', clean))
opin = collections.Counter(re.findall(r'add_opinion_modifier\s*=\s*\{[^}]*modifier\s*=\s*([A-Za-z0-9_]+)', clean))
cosm = collections.Counter(re.findall(r'set_cosmetic_tag\s*=\s*([A-Za-z0-9_]+)', clean))
evs = collections.Counter(re.findall(r'(?:country_event|news_event|state_event)\s*=\s*\{?\s*id\s*=\s*([A-Za-z0-9_.]+)', clean))
cf = collections.Counter(re.findall(r'set_country_flag\s*=\s*([A-Za-z0-9_]+)', clean))
gf = collections.Counter(re.findall(r'set_global_flag\s*=\s*([A-Za-z0-9_]+)', clean))
cfn = collections.Counter(re.findall(r'complete_national_focus\s*=\s*([A-Za-z0-9_]+)', clean))
print("\nЭФФЕКТЫ ДЕРЕВА:")
print("  add_dynamic_modifier: %d вызовов, %d уникальных" % (sum(dyn.values()), len(dyn)))
print("  remove_dynamic_modifier: %s" % dict(dynrm))
print("  has_dynamic_modifier: %s" % dict(dynhas))
print("  add_ideas: %s" % dict(addideas))
print("  add_timed_idea: %s" % dict(timedidea))
print("  add_opinion_modifier: %s" % dict(opin))
print("  set_cosmetic_tag: %s" % dict(cosm))
print("  complete_national_focus: %s" % dict(cfn))
print("  событий вызывается: %s" % dict(evs))
print("  set_country_flag: %s" % sorted(cf))
print("  set_global_flag: %s" % sorted(gf))

# внешние ссылки на фокусы (decisions/categories/events)
print("\nВНЕШНИЕ has_completed_focus / complete_national_focus:")
ext = collections.defaultdict(set)
for p2 in sorted(glob.glob('common/decisions/*.txt') + glob.glob('common/decisions/categories/*.txt') + glob.glob('events/*.txt')):
    tt = strip_comments(open(p2, encoding='utf-8-sig').read())
    for m in re.findall(r'(?:has_completed_focus|complete_national_focus)\s*=\s*([A-Za-z0-9_]+)', tt):
        ext[m].add(os.path.basename(p2))
broken = sorted(k for k in ext if k not in allids)
print("  всего уникальных: %d; НЕ СУЩЕСТВУЕТ В ДЕРЕВЕ: %d -> %s" % (len(ext), len(broken), broken))
for b in broken:
    print("     [!] %-40s <- %s" % (b, ', '.join(sorted(ext[b]))))
    issues.append('внешняя ссылка на несуществующий фокус %s (%s)' % (b, ', '.join(sorted(ext[b]))))

# ================= DYNAMIC MODIFIERS =================
print("\n" + "=" * 70)
print("DYNAMIC MODIFIERS (common/dynamic_modifiers/ROIMOL_ideas.txt)")
print("=" * 70)
dp = 'common/dynamic_modifiers/ROIMOL_ideas.txt'
ok, raw = rd(dp)
dt = strip_comments(raw.decode('utf-8-sig'))
print("скобки %d/%d, BOM=%s, CRLF=%s" % (dt.count('{'), dt.count('}'), raw.startswith(b'\xef\xbb\xbf'), b'\r\n' in raw))
if dt.count('{') != dt.count('}'): issues.append('dynamic_modifiers: дисбаланс скобок')
dm_names = re.findall(r'^([A-Za-z0-9_]+)\s*=\s*\{', dt, re.M)
dm_dups = [k for k, v in collections.Counter(dm_names).items() if v > 1]
print("определено: %d; дубли: %s" % (len(dm_names), dm_dups if dm_dups else 'нет'))
for d in dm_dups: issues.append('dynamic_modifiers: дубль %s' % d)
noloc = [n for n in dm_names if n not in loc]
nodesc = [n for n in dm_names if n + '_desc' not in loc]
print("без loc: %d %s" % (len(noloc), noloc))
print("без _desc: %d %s" % (len(nodesc), nodesc[:20]))
for n in noloc: issues.append('dynamic_modifier %s без локализации' % n)
for n in nodesc: notes.append('dynamic_modifier %s без _desc' % n)
# иконки
dm_icons = collections.Counter(re.findall(r'icon\s*=\s*"?([A-Za-z0-9_]+)"?', dt))
print("иконок: %d уникальных; наших спрайтов среди них: %s" % (len(dm_icons), [i for i in dm_icons if i in sprites]))
# все используемые в проекте
used = collections.Counter()
for p in glob.glob('common/**/*.txt', recursive=True) + glob.glob('events/*.txt'):
    tt = strip_comments(open(p, encoding='utf-8-sig').read())
    for n in re.findall(r'(?:add_dynamic_modifier|has_dynamic_modifier|remove_dynamic_modifier|force_update_dynamic_modifier)\s*=\s*\{[^}]*modifier\s*=\s*([A-Za-z0-9_]+)', tt):
        used[n] += 1
undef = sorted(set(used) - set(dm_names))
unused = sorted(set(dm_names) - set(used))
print("используется в проекте: %d уникальных; НЕ ОПРЕДЕЛЕНО: %s" % (len(used), undef if undef else 'нет'))
for u in undef: issues.append('dynamic_modifier %s используется, но не определён' % u)
print("определено, но не используется: %d -> %s" % (len(unused), unused))
for u in unused: notes.append('dynamic_modifier %s определён, но нигде не применяется' % u)

# ================= IDEAS =================
print("\n" + "=" * 70)
print("IDEAS (common/ideas/)")
print("=" * 70)
idea_names = []
for p in sorted(glob.glob('common/ideas/*.txt')):
    raw = open(p, 'rb').read()
    it = strip_comments(raw.decode('utf-8-sig'))
    print("  %-44s скобки %d/%d BOM=%s" % (p, it.count('{'), it.count('}'), raw.startswith(b'\xef\xbb\xbf')))
    if it.count('{') != it.count('}'): issues.append('%s: дисбаланс скобок' % p)
    if not re.match(r'^\s*ideas\s*=\s*\{', it): issues.append('%s: нет корневого блока ideas = {' % p)
    names = re.findall(r'^\t([A-Za-z0-9_]+)\s*=\s*\{', it, re.M)
    idea_names += names
    print("     идей: %d -> %s" % (len(names), names))
    for n in names:
        if n not in loc: issues.append('идея %s без ключа локализации (%s)' % (n, p))
        if n + '_desc' not in loc: notes.append('идея %s без _desc' % n)
    pics = collections.Counter(re.findall(r'picture\s*=\s*([A-Za-z0-9_]+)', it))
    print("     picture: %s" % dict(pics))
idea_dups = [k for k, v in collections.Counter(idea_names).items() if v > 1]
print("дубли имён идей: %s" % (idea_dups if idea_dups else 'нет'))
coll = sorted(set(idea_names) & set(dm_names))
print("\nКОЛЛИЗИИ имён ideas <-> dynamic_modifiers: %d -> %s" % (len(coll), coll))
for x in coll: issues.append('имя %s определено ОДНОВРЕМЕННО в common/ideas и common/dynamic_modifiers' % x)
# кто как используется
for n in idea_names:
    asidea = 0
    asdyn = 0
    for p in glob.glob('common/**/*.txt', recursive=True) + glob.glob('events/*.txt'):
        tt = strip_comments(open(p, encoding='utf-8-sig').read())
        asidea += len(re.findall(r'(?:add_ideas|add_timed_idea|has_idea|remove_ideas)[^\n]*\b%s\b' % n, tt))
        asdyn += len(re.findall(r'(?:add_dynamic_modifier|has_dynamic_modifier|remove_dynamic_modifier)[^\n]*\b%s\b' % n, tt))
    print("  %-38s add_ideas/timed=%d  add_dynamic_modifier=%d %s" % (n, asidea, asdyn,
          '  <<< ИСПОЛЬЗУЕТСЯ НЕ ТЕМ API' if (n in coll and asdyn) or (n in set(dm_names) and asdyn and n in set(idea_names)) else ''))

# ================= OPINION MODIFIERS =================
print("\n" + "=" * 70)
print("OPINION MODIFIERS")
print("=" * 70)
op = 'common/opinion_modifiers/MOL_opinion_modifiers.txt'
raw = open(op, 'rb').read()
ot = strip_comments(raw.decode('utf-8-sig'))
print("скобки %d/%d BOM=%s CRLF=%s" % (ot.count('{'), ot.count('}'), raw.startswith(b'\xef\xbb\xbf'), b'\r\n' in raw))
if ot.count('{') != ot.count('}'): issues.append('opinion_modifiers: дисбаланс скобок')
op_names = re.findall(r'^([A-Za-z0-9_]+)\s*=\s*\{', ot, re.M)
print("определено: %d -> %s" % (len(op_names), op_names))
for n in op_names:
    blk = re.search(r'^%s\s*=\s*\{(.*?)^\}' % n, ot, re.S | re.M)
    fields = re.findall(r'^\s*([a-z_]+)\s*=\s*([-\d.]+)', blk.group(1), re.M) if blk else []
    st = 'loc OK' if n in loc else 'БЕЗ LOC'
    print("  %-38s %-10s %s" % (n, st, fields))
    if n not in loc: issues.append('opinion_modifier %s без локализации' % n)
used_op = collections.Counter()
for p in glob.glob('common/**/*.txt', recursive=True) + glob.glob('events/*.txt'):
    tt = strip_comments(open(p, encoding='utf-8-sig').read())
    for m in re.findall(r'add_opinion_modifier\s*=\s*\{[^}]*modifier\s*=\s*([A-Za-z0-9_]+)', tt):
        used_op[m] += 1
print("используются: %s" % dict(used_op))
for u in sorted(set(used_op) - set(op_names)):
    issues.append('opinion_modifier %s используется, но не определён' % u)
for u in sorted(set(op_names) - set(used_op)):
    notes.append('opinion_modifier %s определён, но не используется' % u)

# ================= NAMES / UNITS =================
print("\n" + "=" * 70)
print("NAMES / UNITS")
print("=" * 70)
np = 'common/names/01_ROIMOL_names.txt'
nt = strip_comments(open(np, encoding='utf-8-sig').read())
print("names: скобки %d/%d; теги: %s" % (nt.count('{'), nt.count('}'), re.findall(r'^([A-Za-z0-9_]+)\s*=\s*\{', nt, re.M)))
if nt.count('{') != nt.count('}'): issues.append('names: дисбаланс скобок')
up = 'common/units/pmr_units.txt'
ut = strip_comments(open(up, encoding='utf-8-sig').read())
print("units: скобки %d/%d; шаблоны: %s" % (ut.count('{'), ut.count('}'), re.findall(r'name\s*=\s*"([^"]+)"', ut)))

# ================= GFX =================
print("\n" + "=" * 70)
print("GFX (interface/*.gfx)")
print("=" * 70)
print("спрайтов объявлено: %d -> %s" % (len(sprites), sorted(sprites)))
print("текстур: %s" % sorted(textures))
used_sprites = set()
for p in glob.glob('common/**/*.txt', recursive=True):
    tt = open(p, encoding='utf-8-sig').read()
    used_sprites |= set(re.findall(r'GFX_[A-Za-z0-9_]+', tt))
own_used = sorted(s for s in used_sprites if s.startswith('GFX_MOL') or s.startswith('GFX_grigore') or s.startswith('GFX_ion') or s.startswith('GFX_focus_MOL'))
print("наши спрайты, на которые есть ссылки в common/: %s" % own_used)
for s in own_used:
    if s not in sprites:
        issues.append('спрайт %s используется, но не объявлен в interface/*.gfx' % s)
for s in sorted(sprites - set(used_sprites)):
    notes.append('спрайт %s объявлен, но не используется в common/' % s)

# ================= ИТОГ =================
print("\n" + "=" * 70)
print("ИТОГ: ПРОБЛЕМ %d" % len(issues))
for x in issues: print("  [P] " + x)
print("ЗАМЕТОК %d" % len(notes))
for x in notes[:60]: print("  [N] " + x)
if len(notes) > 60: print("  ... ещё %d" % (len(notes) - 60))
