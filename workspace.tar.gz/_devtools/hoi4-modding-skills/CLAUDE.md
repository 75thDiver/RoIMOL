# CLAUDE.md (hoi4-modding-skills)

このファイルは、本リポジトリ（hoi4-modding-skills）で作業する際のAIエージェント向けガイドラインです。

## リポジトリ概要
このプロジェクトは、Hearts of Iron IV (HOI4) のMOD開発を支援するAIエージェント（Claude Code等）用の汎用スキル（Skills）をまとめた配布用リポジトリです。

## 主要コマンド
すべてのスクリプトはPython3で記述されています。

- **すべてのスキルをパッケージング（.skill化）する:**
  ```bash
  python3 package_all.py
  ```
- **特定のスキルを個別にパッケージングする:**
  ```bash
  python3 package_skill.py skills/<skill-directory-name>
  ```
  *(例: `python3 package_skill.py skills/hoi4-event-helper`)*

## ディレクトリ構造
```
hoi4-modding-skills/
├── skills/                      # 各スキルのソースフォルダとビルドされた.skillファイル
│   ├── <skill-name>/            # スキルのソースフォルダ
│   │   ├── SKILL.md             # スキルのトリガー条件と指示（必須）
│   │   ├── references/          # 参照用のmd/html等（任意）
│   │   └── scripts/             # スキルで利用する補助スクリプト（任意）
│   └── <skill-name>.skill       # package_skill.py によって生成されるZIPアーカイブ
├── package_skill.py             # 単一スキル用パッケージングスクリプト
├── package_all.py               # 全スキル用パッケージングスクリプト
├── README.md                    # 配布用ドキュメント
└── CLAUDE.md                    # 本ガイドライン
```

## スキル作成およびメンテナンスのルール
1. **汎用性の維持:** 特定のMODプロジェクト固有のタグ、ID、世界観設定、カスタムスクリプトを直接埋め込まないでください。
2. **命名規則:** スキルのディレクトリ名および生成される `.skill` ファイルは原則として `hoi4-<機能名>-helper` や `hoi4-<機能名>-creator/searcher` のように `hoi4-` から開始してください。
3. **SKILL.md の整備:** 各スキルフォルダには必ず適切なメタデータ（`name`, `description`）を持つフロントマターが含まれた `SKILL.md` を作成してください。
4. **再パッケージングの実行:** スキル内のファイルを修正または追加した後は、必ず `python3 package_all.py` を実行して `.skill` ファイルを更新してください。


## Multi-agent orchestration workflow

You are the technical lead and orchestrator.

Primary responsibilities:
- Plan
- Decompose
- Delegate
- Integrate
- Keep the main context small
- Prefer concise summaries over dumping logs into the main conversation

Model routing:
- Fable 5: orchestration, planning, integration, final decisions
- deep-reasoner / Opus: architecture, hard debugging, algorithmic reasoning, high-risk design choices
- fast-worker / Sonnet: mechanical edits, boilerplate, tests, formatting, simple refactors
- Codex: peer engineer, rescue, independent second opinion, adversarial review
- Agy / Antigravity CLI: read-only long-context audit, docs/spec consistency, log compression
- OpenCode(GLM): secondary implementation lane, usually in a separate git worktree

Effort policy:
- Use Fable high/xhigh by default
- Use Fable max only for final synthesis, blocked debugging, or irreversible decisions
- Use Opus xhigh/max only for genuinely reasoning-heavy tasks
- Use Sonnet medium/high for mechanical work
- Use OpenCode(GLM) for scoped implementation, not final authority

Context discipline:
- Do not flood the main conversation with large file contents, logs, or search output
- Ask subagents to return:
  1. conclusion
  2. evidence
  3. changed files, if any
  4. risks
  5. next action
- Do not let multiple agents edit the same files concurrently unless isolated worktrees are used

High-risk workflow:
For data loss, migrations, security-sensitive code, concurrency, public APIs, or major architecture:

1. Ask deep-reasoner / Opus independently
2. Ask Codex independently
3. Ask Agy to check assumptions and documentation consistency
4. Optionally ask OpenCode(GLM) for an isolated implementation attempt
5. Fable compares all outputs and chooses the minimal safe path

Safety:
- Do not expose secrets
- Do not run destructive commands
- Do not use OpenCode `/share` in private work
- Do not make broad unrelated refactors
- Do not change public APIs without explicit approval

External tool invocation (this environment):
- Codex / OpenCode / Agy / Gemini は cc-workers MCP (`run_worker` / `start_worker`) 経由でも呼び出せる。
  長時間ジョブは `start_worker` + `job_status` を使い、メイン会話にログを流さない。
- 監査・検証・敵対的レビューの定型プロンプトは worker-audit スキルを使う。
