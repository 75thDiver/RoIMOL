# mcp-hoi4 蒸留ノート（2026-09-09）

## 目的

旧 `eightman999/mcp-hoi4` から、MCP transportやCLI packagingではなく、現在の `hoi4-modding-skills` に残す価値のあるHOI4 modding検証知識だけを抽出する。

## 継承する機能概念

### 1. Paradox script validation

- brace / basic syntax validation
- UTF-8 BOM等のencoding異常検出
- CWToolsによるrule-aware validation
- parse結果とdiagnosticをagentが読める形へ正規化

AIがコードを生成するだけでなく、生成後に機械検証するgateとして使う。

### 2. Localization audit

旧実装の `unused-key` / `missing-key` は今後も有用。

- localizationで定義済みだがscriptから参照されないkey
- scriptから参照されるがlocalizationに存在しないkey
- language別の欠落
- key rename後のorphan

これはevent/focus/idea等の個別creator skillとは別の横断auditとして扱う。

### 3. GFX / asset audit

- GFX定義から参照されるが存在しない画像
- assetとして存在するが未参照の画像
- PNG/TGA/DDS変換の必要性
- sprite definitionとpathの不一致
- font metadata / `.fnt` の検査

画像生成skillと、既存assetの整合性auditは分離する。

### 4. Equation / variable explanation

scripted modifiersやvariable演算を、人間が確認しやすい数式へ変換する補助は有用。

ただし旧CLIコマンドをそのまま復活させず、`hoi4-variable-helper` 等の説明・検証能力として必要になった時だけ統合する。

## 継承しないもの

- HOI4専用MCP serverを別途常駐させること
- Node CLIとMCP serverの二重distribution
- 特定agent製品の設定ファイルを正典にすること
- .NET runtime有無で曖昧にvalidation品質が変わる「簡易モード」を無説明で使うこと
- validation failureを生成AIの自然言語判断だけで上書きすること

## 現在のskillsとの対応

既存21 skillsは主にcreation / search支援である。旧 `mcp-hoi4` から見て不足している横断領域は次の3つ。

1. **validator** — CWTools / syntax / encoding validation
2. **localization auditor** — missing / unused / cross-language keys
3. **asset auditor** — GFX path / unused / missing / format validation

これらは今すぐ新skillとして増やす必須事項ではない。実利用で繰り返し必要になった時に、独立skillまたは共通validation pipelineへ昇格する。

## 退役判断

`mcp-hoi4` 自体は2025-09以降実質停止しており、現在のagent workflowはskill/docs中心へ移行している。

したがって旧repoはhistorical prototypeとして退役し、上記4概念だけを本repoの知識として維持する。
